from datetime import datetime, timezone
from uuid import UUID

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session

from app.bootstrap import bootstrap
from app.classify import classify_node
from app.config_jobs import backup_commands, create_vlan_commands, save_commands, set_ip_commands
from app.database import Base, SessionLocal, engine, get_db
from app.deps import current_user
from app.executors import (
    is_dangerous,
    probe_console,
    probe_ssh,
    run_console,
    run_console_commands,
    run_ssh,
    run_ssh_commands,
)
from app.gns3_client import Gns3Error, gns3_get, ping_gns3
from app.models import CommandLog, ConfigBackup, Device, Gns3Settings, User
from app.schemas import (
    BackupOut,
    ChannelBody,
    ConnectTestOut,
    CreateVlanRequest,
    DashboardOut,
    DeviceOut,
    DevicePatch,
    ExecRequest,
    ExecResponse,
    Gns3SettingsIn,
    Gns3SettingsOut,
    JobResponse,
    LoginRequest,
    LogOut,
    SetIpRequest,
    TokenResponse,
    UserOut,
)
from app.security import create_token, encrypt_secret, verify_password

Base.metadata.create_all(bind=engine)
with SessionLocal() as session:
    bootstrap(session)

app = FastAPI(title="Network Automation Platform", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _settings_out(cfg: Gns3Settings) -> Gns3SettingsOut:
    return Gns3SettingsOut(
        protocol=cfg.protocol,
        host=cfg.host,
        port=cfg.port,
        username=cfg.username,
        has_password=bool(cfg.password),
        project_id=cfg.project_id,
    )


def _log_out(row: CommandLog) -> LogOut:
    return LogOut(
        id=row.id,
        device_id=row.device_id,
        user_id=row.user_id,
        channel=row.channel,
        command=row.command,
        output=row.output or "",
        status=row.status,
        error_message=row.error_message,
        created_at=row.created_at,
        device_name=row.device.name if row.device else None,
    )


@app.post("/api/auth/login", response_model=TokenResponse)
def login(body: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == body.username).first()
    if user is None or not verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="اسم المستخدم أو كلمة المرور غير صحيحة")
    token = create_token(str(user.id), user.username, user.role)
    return TokenResponse(access_token=token)


@app.get("/api/auth/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user


@app.get("/api/gns3/settings", response_model=Gns3SettingsOut)
def get_gns3_settings(db: Session = Depends(get_db), _: User = Depends(current_user)):
    cfg = db.get(Gns3Settings, 1)
    if cfg is None:
        raise HTTPException(status_code=500, detail="إعدادات GNS3 غير موجودة")
    return _settings_out(cfg)


@app.put("/api/gns3/settings", response_model=Gns3SettingsOut)
def put_gns3_settings(
    body: Gns3SettingsIn,
    db: Session = Depends(get_db),
    _: User = Depends(current_user),
):
    cfg = db.get(Gns3Settings, 1)
    if cfg is None:
        cfg = Gns3Settings(id=1)
        db.add(cfg)
    cfg.protocol = body.protocol
    cfg.host = body.host
    cfg.port = body.port
    cfg.username = body.username
    if body.password:
        cfg.password = encrypt_secret(body.password)
    cfg.project_id = body.project_id
    db.commit()
    db.refresh(cfg)
    return _settings_out(cfg)


@app.get("/api/gns3/projects")
def list_projects(db: Session = Depends(get_db), _: User = Depends(current_user)):
    cfg = db.get(Gns3Settings, 1)
    try:
        projects = gns3_get(cfg, "/v2/projects")
    except Gns3Error as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.message) from exc
    return [
        {
            "project_id": p.get("project_id"),
            "name": p.get("name"),
            "status": p.get("status"),
        }
        for p in projects
    ]


def _select_project(cfg: Gns3Settings, projects: list[dict]) -> dict:
    if cfg.project_id:
        for project in projects:
            if project.get("project_id") == cfg.project_id:
                return project
    opened = [p for p in projects if p.get("status") == "opened"]
    if opened:
        return opened[0]
    raise HTTPException(status_code=409, detail="افتح مشروع في GNS3 ثم أعد الاكتشاف")


@app.post("/api/gns3/discover")
def discover(db: Session = Depends(get_db), _: User = Depends(current_user)):
    cfg = db.get(Gns3Settings, 1)
    try:
        projects = gns3_get(cfg, "/v2/projects")
    except Gns3Error as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.message) from exc
    project = _select_project(cfg, projects)
    project_id = project["project_id"]
    cfg.project_id = project_id
    try:
        nodes = gns3_get(cfg, f"/v2/projects/{project_id}/nodes")
    except Gns3Error as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.message) from exc

    seen_ids: set[str] = set()
    now = datetime.now(timezone.utc)
    imported = []
    for node in nodes:
        node_id = str(node.get("node_id") or node.get("id"))
        seen_ids.add(node_id)
        name = node.get("name") or node_id
        node_type = node.get("node_type") or node.get("template_id") or ""
        vendor, role = classify_node(name, str(node_type))
        status_raw = str(node.get("status") or "").lower()
        status = "up" if status_raw in {"started", "on"} else "down"
        console_host = node.get("console_host") or cfg.host
        console_port = node.get("console")
        device = db.query(Device).filter(Device.gns3_node_id == node_id).first()
        if device is None:
            device = Device(gns3_node_id=node_id, gns3_project_id=project_id, name=name)
            db.add(device)
        device.gns3_project_id = project_id
        device.name = name
        device.node_type = str(node_type)
        if device.vendor == "unknown":
            device.vendor = vendor
        device.role = role
        device.status = status
        device.console_host = console_host
        device.console_port = console_port
        device.last_seen_at = now
        imported.append(device)

    existing = db.query(Device).filter(Device.gns3_project_id == project_id).all()
    for device in existing:
        if device.gns3_node_id not in seen_ids:
            device.status = "absent"

    db.commit()
    return {
        "project_id": project_id,
        "project_name": project.get("name"),
        "count": len(imported),
        "devices": [DeviceOut.model_validate(d) for d in imported],
    }


@app.get("/api/devices", response_model=list[DeviceOut])
def list_devices(
    include_absent: bool = False,
    db: Session = Depends(get_db),
    _: User = Depends(current_user),
):
    query = db.query(Device)
    if not include_absent:
        query = query.filter(Device.status != "absent")
    return query.order_by(Device.name).all()


@app.get("/api/devices/{device_id}", response_model=DeviceOut)
def get_device(device_id: UUID, db: Session = Depends(get_db), _: User = Depends(current_user)):
    device = db.get(Device, device_id)
    if device is None:
        raise HTTPException(status_code=404, detail="الجهاز غير موجود")
    return device


@app.patch("/api/devices/{device_id}", response_model=DeviceOut)
def patch_device(
    device_id: UUID,
    body: DevicePatch,
    db: Session = Depends(get_db),
    _: User = Depends(current_user),
):
    device = db.get(Device, device_id)
    if device is None:
        raise HTTPException(status_code=404, detail="الجهاز غير موجود")
    if body.mgmt_ip is not None:
        device.mgmt_ip = body.mgmt_ip or None
    if body.ssh_port is not None:
        device.ssh_port = body.ssh_port
    if body.ssh_username is not None:
        device.ssh_username = body.ssh_username or None
    if body.ssh_password:
        device.ssh_password = encrypt_secret(body.ssh_password)
    if body.vendor is not None:
        device.vendor = body.vendor
    db.commit()
    db.refresh(device)
    return device


@app.post("/api/devices/{device_id}/connect-test", response_model=ConnectTestOut)
def connect_test(device_id: UUID, db: Session = Depends(get_db), _: User = Depends(current_user)):
    device = db.get(Device, device_id)
    if device is None:
        raise HTTPException(status_code=404, detail="الجهاز غير موجود")
    return ConnectTestOut(console=probe_console(device), ssh=probe_ssh(device))


@app.post("/api/devices/{device_id}/exec", response_model=ExecResponse)
def exec_command(
    device_id: UUID,
    body: ExecRequest,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    device = db.get(Device, device_id)
    if device is None:
        raise HTTPException(status_code=404, detail="الجهاز غير موجود")
    if device.status == "absent":
        raise HTTPException(status_code=400, detail="الجهاز غير موجود في مشروع GNS3 الحالي")

    if is_dangerous(body.command) and not body.confirm:
        log = CommandLog(
            device_id=device.id,
            user_id=user.id,
            channel=body.channel,
            command=body.command,
            output="",
            status="blocked",
            error_message="أمر خطير يحتاج تأكيد",
        )
        db.add(log)
        db.commit()
        db.refresh(log)
        raise HTTPException(
            status_code=409,
            detail={"status": "blocked", "message": "أمر خطير يحتاج تأكيد", "id": str(log.id)},
        )

    status = "ok"
    output = ""
    error_message = None
    try:
        if body.channel == "console":
            output = run_console(device, body.command)
        else:
            output = run_ssh(device, body.command)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except (ConnectionError, TimeoutError, PermissionError, OSError) as exc:
        status = "error"
        error_message = str(exc)

    log = CommandLog(
        device_id=device.id,
        user_id=user.id,
        channel=body.channel,
        command=body.command,
        output=output,
        status=status,
        error_message=error_message,
    )
    db.add(log)
    db.commit()
    db.refresh(log)
    return ExecResponse(
        id=log.id,
        channel=log.channel,
        command=log.command,
        output=log.output,
        status=log.status,
        error_message=log.error_message,
    )


@app.get("/api/logs", response_model=list[LogOut])
def list_logs(
    device_id: UUID | None = Query(default=None),
    db: Session = Depends(get_db),
    _: User = Depends(current_user),
):
    query = db.query(CommandLog)
    if device_id:
        query = query.filter(CommandLog.device_id == device_id)
    rows = query.order_by(CommandLog.created_at.desc()).limit(100).all()
    return [_log_out(row) for row in rows]


@app.get("/api/dashboard", response_model=DashboardOut)
def dashboard(db: Session = Depends(get_db), _: User = Depends(current_user)):
    devices = db.query(Device).all()
    cfg = db.get(Gns3Settings, 1)
    reachable, message = ping_gns3(cfg)
    logs = db.query(CommandLog).order_by(CommandLog.created_at.desc()).limit(10).all()
    return DashboardOut(
        total=sum(1 for d in devices if d.status != "absent"),
        up=sum(1 for d in devices if d.status == "up"),
        down=sum(1 for d in devices if d.status == "down"),
        absent=sum(1 for d in devices if d.status == "absent"),
        gns3_reachable=reachable,
        gns3_message=message,
        recent_logs=[_log_out(row) for row in logs],
    )


def _get_active_device(db: Session, device_id: UUID) -> Device:
    device = db.get(Device, device_id)
    if device is None:
        raise HTTPException(status_code=404, detail="الجهاز غير موجود")
    if device.status == "absent":
        raise HTTPException(status_code=400, detail="الجهاز غير موجود في مشروع GNS3 الحالي")
    return device


def _run_job(device: Device, channel: str, commands: list[str]) -> tuple[str, str | None]:
    try:
        if channel == "console":
            output = run_console_commands(device, commands)
        else:
            output = run_ssh_commands(device, commands)
        return output, None
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except (ConnectionError, TimeoutError, PermissionError, OSError) as exc:
        return "", str(exc)


def _log_job(db: Session, device: Device, user: User, channel: str, commands: list[str], output: str, error: str | None) -> CommandLog:
    log = CommandLog(
        device_id=device.id,
        user_id=user.id,
        channel=channel,
        command="\n".join(commands),
        output=output,
        status="error" if error else "ok",
        error_message=error,
    )
    db.add(log)
    db.commit()
    db.refresh(log)
    return log


@app.post("/api/devices/{device_id}/set-ip", response_model=JobResponse)
def set_ip(
    device_id: UUID,
    body: SetIpRequest,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    device = _get_active_device(db, device_id)
    try:
        commands = set_ip_commands(device.vendor, body.interface, body.ip, body.mask)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    output, error = _run_job(device, body.channel, commands)
    log = _log_job(db, device, user, body.channel, commands, output, error)
    return JobResponse(
        id=log.id,
        channel=body.channel,
        commands=commands,
        output=output,
        status=log.status,
        error_message=error,
    )


@app.post("/api/devices/{device_id}/vlan", response_model=JobResponse)
def create_vlan(
    device_id: UUID,
    body: CreateVlanRequest,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    device = _get_active_device(db, device_id)
    try:
        commands = create_vlan_commands(device.vendor, body.vlan_id, body.name, body.interface)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    output, error = _run_job(device, body.channel, commands)
    log = _log_job(db, device, user, body.channel, commands, output, error)
    return JobResponse(
        id=log.id,
        channel=body.channel,
        commands=commands,
        output=output,
        status=log.status,
        error_message=error,
    )


@app.post("/api/devices/{device_id}/save", response_model=JobResponse)
def save_config(
    device_id: UUID,
    body: ChannelBody,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    device = _get_active_device(db, device_id)
    commands = save_commands(device.vendor)
    output, error = _run_job(device, body.channel, commands)
    log = _log_job(db, device, user, body.channel, commands, output, error)
    return JobResponse(
        id=log.id,
        channel=body.channel,
        commands=commands,
        output=output,
        status=log.status,
        error_message=error,
    )


@app.post("/api/devices/{device_id}/backup", response_model=BackupOut)
def create_backup(
    device_id: UUID,
    body: ChannelBody,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
):
    device = _get_active_device(db, device_id)
    commands = backup_commands(device.vendor)
    output, error = _run_job(device, body.channel, commands)
    _log_job(db, device, user, body.channel, commands, output, error)
    if error:
        raise HTTPException(status_code=502, detail=error)
    backup = ConfigBackup(
        device_id=device.id,
        user_id=user.id,
        channel=body.channel,
        content=output,
    )
    db.add(backup)
    db.commit()
    db.refresh(backup)
    return BackupOut(
        id=backup.id,
        device_id=device.id,
        device_name=device.name,
        channel=backup.channel,
        content=backup.content,
        created_at=backup.created_at,
    )


@app.get("/api/backups", response_model=list[BackupOut])
def list_backups(
    device_id: UUID | None = Query(default=None),
    db: Session = Depends(get_db),
    _: User = Depends(current_user),
):
    query = db.query(ConfigBackup)
    if device_id:
        query = query.filter(ConfigBackup.device_id == device_id)
    rows = query.order_by(ConfigBackup.created_at.desc()).limit(50).all()
    return [
        BackupOut(
            id=row.id,
            device_id=row.device_id,
            device_name=row.device.name if row.device else None,
            channel=row.channel,
            content=row.content,
            created_at=row.created_at,
        )
        for row in rows
    ]


@app.get("/api/backups/{backup_id}/download")
def download_backup(backup_id: UUID, db: Session = Depends(get_db), _: User = Depends(current_user)):
    backup = db.get(ConfigBackup, backup_id)
    if backup is None:
        raise HTTPException(status_code=404, detail="النسخة غير موجودة")
    name = backup.device.name if backup.device else "device"
    filename = f"{name}-{backup.created_at.strftime('%Y%m%d-%H%M%S')}.cfg"
    return PlainTextResponse(
        backup.content,
        media_type="text/plain",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/api/health")
def health():
    return {"ok": True}
