import ipaddress
import re


def validate_interface(name: str) -> str:
    value = (name or "").strip()
    if not value or len(value) > 64:
        raise ValueError("اسم الواجهة غير صالح")
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9/._:-]*", value):
        raise ValueError("اسم الواجهة غير صالح")
    return value


def validate_ipv4(ip: str) -> str:
    try:
        return str(ipaddress.IPv4Address(ip.strip()))
    except ipaddress.AddressValueError as exc:
        raise ValueError("عنوان IP غير صالح") from exc


def validate_mask_or_prefix(value: str) -> str:
    text = (value or "").strip()
    if re.fullmatch(r"\d{1,2}", text):
        prefix = int(text)
        if prefix < 0 or prefix > 32:
            raise ValueError("البادئة غير صالحة")
        return str(ipaddress.IPv4Network(f"0.0.0.0/{prefix}").netmask)
    try:
        mask = ipaddress.IPv4Address(text)
    except ipaddress.AddressValueError as exc:
        raise ValueError("الماسك غير صالح") from exc
    bits = bin(int(mask)).count("1")
    expected = ipaddress.IPv4Network(f"0.0.0.0/{bits}").netmask
    if int(mask) != int(expected):
        raise ValueError("الماسك غير صالح")
    return str(mask)


def mask_to_prefix(mask: str) -> int:
    return ipaddress.IPv4Network(f"0.0.0.0/{mask}").prefixlen


def validate_vlan_id(vlan_id: int) -> int:
    if vlan_id < 1 or vlan_id > 4094:
        raise ValueError("رقم VLAN يجب أن يكون بين 1 و 4094")
    return vlan_id


def validate_vlan_name(name: str | None) -> str | None:
    if not name:
        return None
    value = name.strip()
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,31}", value):
        raise ValueError("اسم VLAN غير صالح")
    return value


def set_ip_commands(vendor: str, interface: str, ip: str, mask: str) -> list[str]:
    iface = validate_interface(interface)
    address = validate_ipv4(ip)
    netmask = validate_mask_or_prefix(mask)
    if vendor == "juniper":
        prefix = mask_to_prefix(netmask)
        return [
            "configure",
            f"set interfaces {iface} unit 0 family inet address {address}/{prefix}",
            "commit",
        ]
    return [
        "configure terminal",
        f"interface {iface}",
        f"ip address {address} {netmask}",
        "no shutdown",
        "end",
    ]


def create_vlan_commands(
    vendor: str,
    vlan_id: int,
    name: str | None = None,
    interface: str | None = None,
) -> list[str]:
    vid = validate_vlan_id(vlan_id)
    vname = validate_vlan_name(name)
    iface = validate_interface(interface) if interface else None
    if vendor == "juniper":
        label = vname or f"VLAN{vid}"
        cmds = ["configure", f"set vlans {label} vlan-id {vid}"]
        if iface:
            cmds.append(f"set interfaces {iface} unit 0 family ethernet-switching vlan members {label}")
        cmds.append("commit")
        return cmds
    cmds = ["configure terminal", f"vlan {vid}"]
    if vname:
        cmds.append(f"name {vname}")
    cmds.append("exit")
    if iface:
        cmds.extend(
            [
                f"interface {iface}",
                "switchport mode access",
                f"switchport access vlan {vid}",
            ]
        )
    cmds.append("end")
    return cmds


def save_commands(vendor: str) -> list[str]:
    if vendor == "juniper":
        return ["commit"]
    return ["write memory"]


def backup_commands(vendor: str) -> list[str]:
    if vendor == "juniper":
        return ["show configuration"]
    return ["terminal length 0", "show running-config"]
