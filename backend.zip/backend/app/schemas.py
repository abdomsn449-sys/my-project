from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    id: UUID
    username: str
    role: str

    model_config = {"from_attributes": True}


class Gns3SettingsIn(BaseModel):
    protocol: str = "http"
    host: str = "127.0.0.1"
    port: int = 3080
    username: str | None = None
    password: str | None = None
    project_id: str | None = None


class Gns3SettingsOut(BaseModel):
    protocol: str
    host: str
    port: int
    username: str | None
    has_password: bool
    project_id: str | None


class DevicePatch(BaseModel):
    mgmt_ip: str | None = None
    ssh_port: int | None = None
    ssh_username: str | None = None
    ssh_password: str | None = None
    vendor: str | None = None


class DeviceOut(BaseModel):
    id: UUID
    gns3_node_id: str
    gns3_project_id: str
    name: str
    node_type: str
    vendor: str
    role: str
    status: str
    console_host: str | None
    console_port: int | None
    mgmt_ip: str | None
    ssh_port: int
    ssh_username: str | None
    last_seen_at: datetime | None

    model_config = {"from_attributes": True}


class ExecRequest(BaseModel):
    command: str
    channel: str = Field(pattern="^(console|ssh)$")
    confirm: bool = False


class ExecResponse(BaseModel):
    id: UUID
    channel: str
    command: str
    output: str
    status: str
    error_message: str | None


class LogOut(BaseModel):
    id: UUID
    device_id: UUID
    user_id: UUID
    channel: str
    command: str
    output: str
    status: str
    error_message: str | None
    created_at: datetime
    device_name: str | None = None

    model_config = {"from_attributes": True}


class DashboardOut(BaseModel):
    total: int
    up: int
    down: int
    absent: int
    gns3_reachable: bool
    gns3_message: str
    recent_logs: list[LogOut]


class ConnectTestOut(BaseModel):
    console: str
    ssh: str


class ChannelBody(BaseModel):
    channel: str = Field(default="console", pattern="^(console|ssh)$")


class SetIpRequest(ChannelBody):
    interface: str
    ip: str
    mask: str


class CreateVlanRequest(ChannelBody):
    vlan_id: int
    name: str | None = None
    interface: str | None = None


class JobResponse(BaseModel):
    id: UUID
    channel: str
    commands: list[str]
    output: str
    status: str
    error_message: str | None


class BackupOut(BaseModel):
    id: UUID
    device_id: UUID
    device_name: str | None = None
    channel: str
    content: str
    created_at: datetime
