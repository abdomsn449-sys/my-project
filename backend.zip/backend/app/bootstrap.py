from sqlalchemy.orm import Session

from app.config import settings
from app.models import Gns3Settings, User
from app.security import hash_password


def bootstrap(db: Session) -> None:
    if db.query(User).filter(User.username == settings.nap_admin_user).first() is None:
        db.add(
            User(
                username=settings.nap_admin_user,
                password_hash=hash_password(settings.nap_admin_password),
                role="admin",
            )
        )
    if db.get(Gns3Settings, 1) is None:
        db.add(Gns3Settings(id=1, protocol="http", host="127.0.0.1", port=3080))
    db.commit()
