import httpx

from app.models import Gns3Settings
from app.security import decrypt_secret


class Gns3Error(Exception):
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(message)


def _base_url(cfg: Gns3Settings) -> str:
    return f"{cfg.protocol}://{cfg.host}:{cfg.port}"


def _auth(cfg: Gns3Settings):
    if cfg.username:
        return (cfg.username, decrypt_secret(cfg.password) or "")
    return None


def gns3_get(cfg: Gns3Settings, path: str, timeout: float = 5.0) -> list | dict:
    url = f"{_base_url(cfg)}{path}"
    try:
        response = httpx.get(url, auth=_auth(cfg), timeout=timeout)
    except httpx.HTTPError as exc:
        raise Gns3Error(503, f"GNS3 غير متاح على {_base_url(cfg)}: {exc}") from exc
    if response.status_code >= 400:
        raise Gns3Error(response.status_code, f"GNS3 رفض الطلب ({response.status_code})")
    return response.json()


def ping_gns3(cfg: Gns3Settings) -> tuple[bool, str]:
    try:
        gns3_get(cfg, "/v2/version")
        return True, f"متصل بـ {_base_url(cfg)}"
    except Gns3Error as exc:
        return False, exc.message
