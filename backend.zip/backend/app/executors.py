import socket
import telnetlib
from typing import Callable

from netmiko import ConnectHandler
from netmiko.exceptions import NetmikoAuthenticationException, NetmikoTimeoutException

from app.models import Device
from app.security import decrypt_secret

DANGEROUS = {
    "reload",
    "reboot",
    "erase startup-config",
    "write erase",
    "request system reboot",
    "request system zeroize",
}

SSH_TYPES = {"cisco": "cisco_ios", "juniper": "juniper"}


def is_dangerous(command: str) -> bool:
    return command.strip().lower() in DANGEROUS


def _read_until_prompt(tn: telnetlib.Telnet, timeout: float = 30) -> str:
    chunks: list[bytes] = []
    tn.write(b"\r\n")
    try:
        data = tn.read_until(b"#", timeout=timeout)
        if not data:
            data = tn.read_very_eager()
        chunks.append(data)
    except EOFError:
        pass
    return b"".join(chunks).decode("utf-8", errors="replace")


def _send_console(tn: telnetlib.Telnet, command: str, timeout: int) -> str:
    tn.write(command.encode() + b"\r\n")
    output = tn.read_until(b"#", timeout=timeout)
    if not output:
        output = tn.read_very_eager()
    return output.decode("utf-8", errors="replace")


def run_console_commands(device: Device, commands: list[str], timeout: int = 30) -> str:
    if not device.console_host or not device.console_port:
        raise ValueError("منفذ Console غير متاح لهذا الجهاز")
    try:
        tn = telnetlib.Telnet(device.console_host, device.console_port, timeout=timeout)
    except (OSError, socket.timeout) as exc:
        raise ConnectionError(f"فشل الاتصال بالـ Console: {exc}") from exc
    try:
        _read_until_prompt(tn, timeout=8)
        chunks: list[str] = []
        for command in commands:
            chunks.append(_send_console(tn, command, timeout))
        return "\n".join(part.strip() for part in chunks if part.strip())
    finally:
        tn.close()


def run_console(device: Device, command: str, timeout: int = 30) -> str:
    return run_console_commands(device, [command], timeout=timeout)


def _ssh_params(device: Device, timeout: int) -> dict:
    if not device.mgmt_ip or not device.ssh_username or not device.ssh_password:
        raise ValueError("SSH غير مضبوط: يلزم عنوان الإدارة واسم المستخدم وكلمة المرور")
    device_type = SSH_TYPES.get(device.vendor)
    if not device_type:
        raise ValueError("SSH مدعوم فقط لأجهزة Cisco و Juniper")
    return {
        "device_type": device_type,
        "host": device.mgmt_ip,
        "port": device.ssh_port or 22,
        "username": device.ssh_username,
        "password": decrypt_secret(device.ssh_password),
        "timeout": timeout,
        "auth_timeout": timeout,
        "banner_timeout": timeout,
        "fast_cli": False,
    }


def _ssh_send(conn, commands: list[str], timeout: int) -> str:
    outputs = []
    config_mode = False
    for command in commands:
        if command in {"configure terminal", "configure"}:
            config_mode = True
            outputs.append(conn.send_command(command, expect_string=r"[)#]", read_timeout=timeout))
            continue
        if command in {"end", "commit"}:
            outputs.append(conn.send_command(command, expect_string=r"[>#]", read_timeout=timeout))
            config_mode = False
            continue
        if config_mode:
            outputs.append(conn.send_command(command, expect_string=r"[)#]", read_timeout=timeout))
        else:
            outputs.append(conn.send_command(command, read_timeout=timeout))
    return "\n".join(str(part) for part in outputs if part)


def run_ssh_commands(device: Device, commands: list[str], timeout: int = 30) -> str:
    params = _ssh_params(device, timeout)
    try:
        with ConnectHandler(**params) as conn:
            return _ssh_send(conn, commands, timeout)
    except NetmikoAuthenticationException as exc:
        raise PermissionError(f"فشل توثيق SSH: {exc}") from exc
    except NetmikoTimeoutException as exc:
        raise TimeoutError(f"انتهت مهلة SSH: {exc}") from exc


def run_ssh(device: Device, command: str, timeout: int = 30) -> str:
    return run_ssh_commands(device, [command], timeout=timeout)


def probe_console(device: Device) -> str:
    if not device.console_host or not device.console_port:
        return "غير متاح"
    try:
        with socket.create_connection((device.console_host, device.console_port), timeout=5):
            return "متاح"
    except OSError as exc:
        return f"فشل: {exc}"


def probe_ssh(device: Device) -> str:
    if not device.mgmt_ip:
        return "غير مضبوط"
    try:
        with socket.create_connection((device.mgmt_ip, device.ssh_port or 22), timeout=5):
            return "المنفذ مفتوح"
    except OSError as exc:
        return f"فشل: {exc}"


ExecFn = Callable[[Device, str], str]
