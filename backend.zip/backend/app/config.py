from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql://nap:nap@127.0.0.1:5432/nap"
    nap_jwt_secret: str = "dev-jwt-secret-change-me-32bytes-min"
    nap_encryption_key: str = "w423fwLxKeEa1g1sdMP5NpK71AhioC7KOavfkHYlN_Q="
    nap_admin_user: str = "admin"
    nap_admin_password: str = "admin"
    jwt_hours: int = 12


settings = Settings()
