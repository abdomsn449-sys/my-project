from uuid import UUID

from sqlalchemy.orm import Session

from app.executors import is_dangerous, run_console, run_ssh
from app.models import CommandLog, Device, PlaybookResult, PlaybookRun, User


def select_devices(db: Session, device_ids: list[UUID] | None) -> list[Device]:
    query = db.query(Device).filter(Device.status != "absent")
    if device_ids:
        query = query.filter(Device.id.in_(device_ids))
    return query.order_by(Device.name).all()


def execute_playbook(
    db: Session,
    user: User,
    name: str,
    command: str,
    channel: str,
    devices: list[Device],
    confirm: bool,
) -> PlaybookRun:
    run = PlaybookRun(
        name=name or command[:80],
        command=command,
        channel=channel,
        user_id=user.id,
        status="ok",
    )
    if is_dangerous(command) and not confirm:
        run.status = "blocked"
        db.add(run)
        db.commit()
        db.refresh(run)
        return run

    db.add(run)
    db.flush()

    ok_count = 0
    error_count = 0
    for device in devices:
        status = "ok"
        output = ""
        error_message = None
        try:
            if channel == "console":
                output = run_console(device, command)
            else:
                output = run_ssh(device, command)
            ok_count += 1
        except ValueError as exc:
            status = "error"
            error_message = str(exc)
            error_count += 1
        except (ConnectionError, TimeoutError, PermissionError, OSError) as exc:
            status = "error"
            error_message = str(exc)
            error_count += 1
        db.add(
            PlaybookResult(
                playbook_run_id=run.id,
                device_id=device.id,
                status=status,
                output=output,
                error_message=error_message,
            )
        )
        db.add(
            CommandLog(
                device_id=device.id,
                user_id=user.id,
                channel=channel,
                command=command,
                output=output,
                status=status,
                error_message=error_message,
            )
        )

    if error_count and ok_count:
        run.status = "partial"
    elif error_count:
        run.status = "error"
    else:
        run.status = "ok"
    db.commit()
    db.refresh(run)
    return run
