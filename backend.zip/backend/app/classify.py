def classify_node(name: str, node_type: str) -> tuple[str, str]:
    blob = f"{name} {node_type}".lower()
    if any(token in blob for token in ("vpcs", "cloud", "qemu-pc", "pc")):
        return "unknown", "pc"
    if any(token in blob for token in ("junos", "vmx", "vsrx", "vqfx", "juniper")):
        role = "switch" if "switch" in blob or "qfx" in blob else "router"
        return "juniper", role
    if any(token in blob for token in ("iosl2", "l2", "switch", "viosl2", "catalyst")):
        vendor = "cisco" if any(t in blob for t in ("ios", "vios", "csr", "cisco", "l2", "switch")) else "unknown"
        return vendor, "switch"
    if any(token in blob for token in ("ios", "csr", "vios", "iosv", "cisco", "dynamips")):
        return "cisco", "router"
    return "unknown", "other"
