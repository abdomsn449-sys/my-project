from unittest.mock import patch
from uuid import uuid4

from fastapi.testclient import TestClient

from app.config_jobs import parse_interfaces, static_route_commands
from app.database import SessionLocal
from app.main import app
from app.models import Device, User
from app.security import hash_password

client = TestClient(app)


def auth_header(username="admin", password="admin") -> dict:
    response = client.post("/api/auth/login", json={"username": username, "password": password})
    assert response.status_code == 200
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def seed_device(name="R1", vendor="cisco", status="up") -> Device:
    db = SessionLocal()
    try:
        device = Device(
            gns3_node_id=str(uuid4()),
            gns3_project_id=str(uuid4()),
            name=name,
            node_type="iosv",
            vendor=vendor,
            role="router",
            status=status,
            console_host="127.0.0.1",
            console_port=5001,
        )
        db.add(device)
        db.commit()
        db.refresh(device)
        return device
    finally:
        db.close()


def test_cisco_static_route_commands():
    cmds = static_route_commands("cisco", "10.0.0.0", "24", "192.168.1.1")
    assert "ip route 10.0.0.0 255.255.255.0 192.168.1.1" in cmds


def test_juniper_static_route_commands():
    cmds = static_route_commands("juniper", "10.0.0.0", "255.255.255.0", "192.168.1.1")
    assert "set routing-options static route 10.0.0.0/24 next-hop 192.168.1.1" in cmds


def test_parse_cisco_interfaces():
    output = "Interface              IP-Address      OK? Method Status                Protocol\nGigabitEthernet0/0     192.168.1.1     YES manual up                    up\n"
    rows = parse_interfaces("cisco", output)
    assert rows[0]["name"] == "GigabitEthernet0/0"
    assert rows[0]["ip"] == "192.168.1.1"


@patch("app.main.gns3_post")
def test_start_node(mock_post):
    device = seed_device("R-start")
    response = client.post(f"/api/devices/{device.id}/start", headers=auth_header())
    assert response.status_code == 200
    assert response.json()["action"] == "start"
    mock_post.assert_called_once()


@patch("app.main.gns3_get")
def test_topology(mock_get):
    device = seed_device("R-topo")
    project_id = device.gns3_project_id
    node_id = device.gns3_node_id
    mock_get.side_effect = [
        [{"project_id": project_id, "name": "lab", "status": "opened"}],
        [{"node_id": node_id, "name": "R-topo", "node_type": "iosv", "status": "started", "x": 10, "y": 20, "ports": []}],
        [
            {
                "link_id": "l1",
                "nodes": [
                    {"node_id": node_id, "adapter_number": 0, "port_number": 0},
                    {"node_id": "other", "adapter_number": 0, "port_number": 1},
                ],
            }
        ],
    ]
    db = SessionLocal()
    from app.models import Gns3Settings

    cfg = db.get(Gns3Settings, 1)
    cfg.project_id = project_id
    db.commit()
    db.close()
    response = client.get("/api/gns3/topology", headers=auth_header())
    assert response.status_code == 200
    body = response.json()
    assert body["nodes"][0]["name"] == "R-topo"
    assert body["links"][0]["source"] == node_id


@patch("app.playbooks.run_console", return_value="Cisco IOS Software")
def test_playbook_run(mock_run):
    first = seed_device("R-pb1")
    second = seed_device("R-pb2")
    response = client.post(
        "/api/playbooks/run",
        headers=auth_header(),
        json={"name": "show-version", "command": "show version", "channel": "console", "device_ids": [str(first.id), str(second.id)]},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert len(body["results"]) == 2
    assert mock_run.call_count == 2


def test_playbook_dangerous_blocked():
    device = seed_device("R-pb-danger")
    response = client.post(
        "/api/playbooks/run",
        headers=auth_header(),
        json={"command": "reload", "channel": "console", "device_ids": [str(device.id)]},
    )
    assert response.status_code == 409
    assert response.json()["detail"]["status"] == "blocked"


@patch("app.main.run_console_commands", return_value="OK")
def test_static_route_api(mock_run):
    device = seed_device("R-route")
    response = client.post(
        f"/api/devices/{device.id}/static-route",
        headers=auth_header(),
        json={"network": "10.8.0.0", "mask": "24", "next_hop": "192.168.1.1", "channel": "console"},
    )
    assert response.status_code == 200
    assert "ip route 10.8.0.0 255.255.255.0 192.168.1.1" in response.json()["commands"]


def test_operator_cannot_create_user():
    db = SessionLocal()
    if db.query(User).filter(User.username == "ops").first() is None:
        db.add(User(username="ops", password_hash=hash_password("ops123"), role="operator"))
        db.commit()
    db.close()
    response = client.post(
        "/api/users",
        headers=auth_header("ops", "ops123"),
        json={"username": "newops", "password": "pass123", "role": "operator"},
    )
    assert response.status_code == 403


def test_admin_creates_user():
    username = f"user-{uuid4().hex[:8]}"
    response = client.post(
        "/api/users",
        headers=auth_header(),
        json={"username": username, "password": "pass123", "role": "operator"},
    )
    assert response.status_code == 200
    assert response.json()["username"] == username
    listed = client.get("/api/users", headers=auth_header())
    assert any(row["username"] == username for row in listed.json())
