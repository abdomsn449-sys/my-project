from unittest.mock import patch
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.main import app
from app.models import Device

client = TestClient(app)


def auth_header() -> dict:
    response = client.post("/api/auth/login", json={"username": "admin", "password": "admin"})
    assert response.status_code == 200
    token = response.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_login_success():
    response = client.post("/api/auth/login", json={"username": "admin", "password": "admin"})
    assert response.status_code == 200
    assert "access_token" in response.json()


def test_login_failure():
    response = client.post("/api/auth/login", json={"username": "admin", "password": "wrong"})
    assert response.status_code == 401


def test_unauthenticated():
    response = client.get("/api/devices")
    assert response.status_code == 401


def test_me():
    response = client.get("/api/auth/me", headers=auth_header())
    assert response.status_code == 200
    assert response.json()["username"] == "admin"


def _seed_device(node_id: str, project_id: str, name: str, status: str = "up") -> Device:
    db: Session = SessionLocal()
    try:
        device = Device(
            gns3_node_id=node_id,
            gns3_project_id=project_id,
            name=name,
            node_type="iosv",
            vendor="cisco",
            role="router",
            status=status,
            console_host="127.0.0.1",
            console_port=5001,
        )
        db.add(device)
        db.commit()
        db.refresh(device)
        return device
    finally:
        db.close()


@patch("app.main.gns3_get")
def test_discover_upsert_and_absent(mock_get):
    project_id = str(uuid4())
    keep_id = str(uuid4())
    gone_id = str(uuid4())
    _seed_device(gone_id, project_id, "R-old")

    mock_get.side_effect = [
        [{"project_id": project_id, "name": "lab", "status": "opened"}],
        [
            {
                "node_id": keep_id,
                "name": "R1",
                "node_type": "iosv",
                "status": "started",
                "console_host": "127.0.0.1",
                "console": 5002,
            }
        ],
    ]
    headers = auth_header()
    with patch("app.main.gns3_get", mock_get):
        db = SessionLocal()
        from app.models import Gns3Settings

        cfg = db.get(Gns3Settings, 1)
        cfg.project_id = project_id
        db.commit()
        db.close()
        response = client.post("/api/gns3/discover", headers=headers)

    assert response.status_code == 200
    names = [d["name"] for d in response.json()["devices"]]
    assert "R1" in names

    listed = client.get("/api/devices", headers=headers).json()
    assert all(d["name"] != "R-old" for d in listed)

    all_devices = client.get("/api/devices?include_absent=true", headers=headers).json()
    old = next(d for d in all_devices if d["name"] == "R-old")
    assert old["status"] == "absent"


@patch("app.main.run_console", return_value="GigabitEthernet0/0 up")
def test_exec_console_ok(mock_run):
    device = _seed_device(str(uuid4()), str(uuid4()), "R-exec")
    response = client.post(
        f"/api/devices/{device.id}/exec",
        headers=auth_header(),
        json={"command": "show ip interface brief", "channel": "console"},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert "GigabitEthernet" in body["output"]
    mock_run.assert_called_once()


def test_dangerous_command_blocked():
    device = _seed_device(str(uuid4()), str(uuid4()), "R-danger")
    response = client.post(
        f"/api/devices/{device.id}/exec",
        headers=auth_header(),
        json={"command": "reload", "channel": "console"},
    )
    assert response.status_code == 409
    assert response.json()["detail"]["status"] == "blocked"


@patch("app.main.run_console_commands", return_value="OK")
def test_set_ip(mock_run):
    device = _seed_device(str(uuid4()), str(uuid4()), "R-ip")
    response = client.post(
        f"/api/devices/{device.id}/set-ip",
        headers=auth_header(),
        json={"interface": "GigabitEthernet0/0", "ip": "192.168.10.1", "mask": "24", "channel": "console"},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert "ip address 192.168.10.1 255.255.255.0" in body["commands"]
    mock_run.assert_called_once()


@patch("app.main.run_console_commands", return_value="OK")
def test_create_vlan(mock_run):
    device = _seed_device(str(uuid4()), str(uuid4()), "SW-vlan")
    device_id = device.id
    db = SessionLocal()
    row = db.get(Device, device_id)
    row.role = "switch"
    db.commit()
    db.close()
    response = client.post(
        f"/api/devices/{device_id}/vlan",
        headers=auth_header(),
        json={"vlan_id": 10, "name": "USERS", "channel": "console"},
    )
    assert response.status_code == 200
    assert "vlan 10" in response.json()["commands"]


@patch("app.main.run_console_commands", return_value="Building configuration...")
def test_save_config(mock_run):
    device = _seed_device(str(uuid4()), str(uuid4()), "R-save")
    response = client.post(
        f"/api/devices/{device.id}/save",
        headers=auth_header(),
        json={"channel": "console"},
    )
    assert response.status_code == 200
    assert response.json()["commands"] == ["write memory"]


@patch("app.main.run_console_commands", return_value="!\nhostname R1\n")
def test_backup(mock_run):
    device = _seed_device(str(uuid4()), str(uuid4()), "R-backup")
    headers = auth_header()
    response = client.post(
        f"/api/devices/{device.id}/backup",
        headers=headers,
        json={"channel": "console"},
    )
    assert response.status_code == 200
    backup_id = response.json()["id"]
    listed = client.get("/api/backups", headers=headers)
    assert listed.status_code == 200
    assert any(row["id"] == backup_id for row in listed.json())
    download = client.get(f"/api/backups/{backup_id}/download", headers=headers)
    assert download.status_code == 200
    assert "hostname R1" in download.text
