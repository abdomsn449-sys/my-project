from app.config_jobs import create_vlan_commands, save_commands, set_ip_commands


def test_cisco_set_ip_commands():
    cmds = set_ip_commands("cisco", "GigabitEthernet0/0", "192.168.1.1", "24")
    assert "interface GigabitEthernet0/0" in cmds
    assert "ip address 192.168.1.1 255.255.255.0" in cmds


def test_juniper_set_ip_commands():
    cmds = set_ip_commands("juniper", "ge-0/0/0", "10.0.0.1", "255.255.255.0")
    assert "set interfaces ge-0/0/0 unit 0 family inet address 10.0.0.1/24" in cmds
    assert "commit" in cmds


def test_cisco_vlan_with_interface():
    cmds = create_vlan_commands("cisco", 10, "USERS", "FastEthernet0/1")
    assert "vlan 10" in cmds
    assert "name USERS" in cmds
    assert "switchport access vlan 10" in cmds


def test_invalid_ip():
    try:
        set_ip_commands("cisco", "Gi0/0", "999.1.1.1", "255.255.255.0")
        assert False
    except ValueError:
        pass


def test_save_cisco():
    assert save_commands("cisco") == ["write memory"]
