from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import httpx
import socket

GNS3 = "http://127.0.0.1:3080"
app = FastAPI()

HTML = r"""
<!doctype html>
<html lang="ar">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>منصة أتمتة الشبكة</title>
<style>
:root{--bg:#07111f;--panel:#0f1c2e;--card:#15263d;--line:#274060;--text:#e8f1ff;--muted:#93a7c2;--accent:#3ee0c1;--danger:#ff6b7a}
*{box-sizing:border-box}
html,body,#root{margin:0;min-height:100%}
body{font-family:"Segoe UI",Tahoma,sans-serif;background:radial-gradient(circle at top right,#123154,var(--bg) 40%);color:var(--text);direction:rtl}
a{color:var(--accent);text-decoration:none}
.shell{display:grid;grid-template-columns:240px 1fr;min-height:100vh}
.sidebar{background:#0b1726;border-left:1px solid var(--line);padding:24px 18px;display:flex;flex-direction:column;gap:24px}
.brand{display:flex;gap:12px;align-items:center}
.brand-mark{width:42px;height:42px;display:grid;place-items:center;border-radius:12px;background:var(--accent);color:#04221b;font-weight:800}
.brand small{display:block;color:var(--muted)}
nav{display:flex;flex-direction:column;gap:8px}
nav a,button,.logout{border:0;border-radius:10px;padding:10px 12px;color:var(--text);background:transparent;cursor:pointer;font:inherit;text-align:right}
nav a.active,button{background:var(--accent);color:#04221b;font-weight:700}
.logout{margin-top:auto;background:#2a3344;color:#fff}
.content{padding:32px}
.page-head{display:flex;justify-content:space-between;align-items:center;gap:16px}
.card,.table-wrap,.stats article,.terminal{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px}
label{display:flex;flex-direction:column;gap:6px;margin-bottom:12px;color:var(--muted)}
input,select{background:#0d1a2b;border:1px solid var(--line);color:var(--text);border-radius:8px;padding:10px}
.banner{padding:12px 14px;border-radius:10px;margin-bottom:16px}
.banner.error{background:#3a1820;color:#ffd5da}
.banner.ok{background:#12362f;color:#c8fff4}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}
.stats strong{display:block;font-size:32px}
.table-wrap{overflow:auto;padding:0}
table{width:100%;border-collapse:collapse}
th,td{padding:12px;border-bottom:1px solid var(--line);text-align:right}
.pill{padding:4px 8px;border-radius:999px;background:#334155}
.pill.started,.pill.up{background:#14532d}
.pill.stopped,.pill.down{background:#7f1d1d}
.terminal{min-height:280px;background:#071018;font-family:ui-monospace,Menlo,monospace;white-space:pre-wrap}
.login-wrap{min-height:100vh;display:grid;place-items:center}
.login-card{width:380px}
.muted{color:var(--muted)}
.actions{display:flex;gap:10px}
.hidden{display:none}
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
@media(max-width:900px){.grid-2{grid-template-columns:1fr}}
@media(max-width:900px){.shell,.stats{grid-template-columns:1fr}}
</style>
</head>
<body>
<div id="login" class="login-wrap">
  <form class="card login-card" onsubmit="return doLogin(event)">
    <h1>منصة أتمتة الشبكة</h1>
    <p class="muted">تسجيل الدخول لإدارة مختبر GNS3</p>
    <label>اسم المستخدم<input id="user" dir="ltr" value="admin"></label>
    <label>كلمة المرور<input id="pass" type="password" dir="ltr" value="admin"></label>
    <div id="loginErr" class="banner error hidden"></div>
    <button type="submit">دخول</button>
  </form>
</div>
<div id="app" class="shell hidden">
  <aside class="sidebar">
    <div class="brand">
      <span class="brand-mark">NAP</span>
      <div><strong>أتمتة الشبكة</strong><small>مختبر GNS3</small></div>
    </div>
    <nav>
      <a href="#" id="nav-dash" class="active" onclick="show('dash');return false">لوحة التحكم</a>
      <a href="#" id="nav-dev" onclick="show('dev');return false">الأجهزة</a>
      <a href="#" id="nav-term" onclick="show('term');return false">طرفية</a>
      <a href="#" id="nav-cfg" onclick="show('cfg');return false">الكونفيج</a>
      <a href="#" id="nav-set" onclick="show('set');return false">إعدادات GNS3</a>
    </nav>
    <button class="logout" type="button" onclick="logout()">خروج</button>
  </aside>
  <main class="content">
    <section id="page-dash">
      <header class="page-head">
        <h1>لوحة التحكم</h1>
        <button type="button" onclick="discover()">اكتشاف أجهزة GNS3</button>
      </header>
      <div id="dashMsg"></div>
      <div class="stats">
        <article><span>الأجهزة</span><strong id="c-total">0</strong></article>
        <article><span>تعمل</span><strong id="c-up">0</strong></article>
        <article><span>متوقفة</span><strong id="c-down">0</strong></article>
        <article><span>غائبة</span><strong id="c-abs">0</strong></article>
      </div>
      <h2>آخر الأوامر</h2>
      <div class="table-wrap">
        <table>
          <thead><tr><th>الجهاز</th><th>الأمر</th><th>الحالة</th></tr></thead>
          <tbody id="logs"></tbody>
        </table>
      </div>
    </section>
    <section id="page-dev" class="hidden">
      <header class="page-head">
        <h1>الأجهزة</h1>
        <button type="button" onclick="discover()">اكتشاف</button>
      </header>
      <div id="devMsg"></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>الاسم</th><th>النوع</th><th>الحالة</th><th>Console</th><th></th></tr></thead>
          <tbody id="devs"></tbody>
        </table>
      </div>
    </section>
    <section id="page-term" class="hidden">
      <header class="page-head"><h1>طرفية</h1></header>
      <form class="card" onsubmit="return execCmd(event)">
        <label>الجهاز
          <select id="devsel"></select>
        </label>
        <label>الأمر
          <input id="cmd" dir="ltr" value="show ip interface brief">
        </label>
        <button type="submit">تنفيذ</button>
      </form>
      <pre class="terminal" id="out" dir="ltr">الناتج سيظهر هنا</pre>
    </section>
    <section id="page-cfg" class="hidden">
      <header class="page-head"><h1>تغيير الكونفيج</h1></header>
      <div id="cfgMsg"></div>
      <div class="grid-2">
        <form class="card" onsubmit="return setIp(event)">
          <h2>تغيير IP</h2>
          <label>الجهاز<select id="cfgdev"></select></label>
          <label>الواجهة<input id="iface" dir="ltr" value="GigabitEthernet0/0"></label>
          <label>IP<input id="ipaddr" dir="ltr" value="192.168.1.1"></label>
          <label>الماسك<input id="mask" dir="ltr" value="255.255.255.0"></label>
          <button type="submit">تطبيق IP</button>
        </form>
        <form class="card" onsubmit="return setVlan(event)">
          <h2>إنشاء VLAN</h2>
          <label>رقم VLAN<input id="vlanid" dir="ltr" type="number" value="10"></label>
          <label>الاسم<input id="vlanname" dir="ltr" value="USERS"></label>
          <label>واجهة (اختياري)<input id="vlanif" dir="ltr"></label>
          <button type="submit">إنشاء VLAN</button>
        </form>
      </div>
      <div class="page-head">
        <button type="button" onclick="saveCfg()">حفظ الكونفيج</button>
        <button type="button" onclick="doBackup()">Backup</button>
      </div>
      <pre class="terminal" id="cfgout" dir="ltr">الناتج سيظهر هنا</pre>
    </section>
    <section id="page-set" class="hidden">
      <header class="page-head"><h1>إعدادات GNS3</h1></header>
      <form class="card" onsubmit="return saveSet(event)">
        <label>المضيف<input id="host" dir="ltr" value="127.0.0.1"></label>
        <label>المنفذ<input id="port" dir="ltr" type="number" value="3080"></label>
        <button type="submit">حفظ</button>
      </form>
      <p class="muted">المنصة لازم تكون على نفس جهاز GNS3. الافتراضي 127.0.0.1:3080</p>
    </section>
  </main>
</div>
<script>
let devices=[], logs=[];
function $(id){return document.getElementById(id)}
function doLogin(e){
  e.preventDefault();
  if($("user").value==="admin" && $("pass").value==="admin"){
    $("login").classList.add("hidden");
    $("app").classList.remove("hidden");
    discover();
  } else {
    $("loginErr").textContent="اسم المستخدم أو كلمة المرور غير صحيحة";
    $("loginErr").classList.remove("hidden");
  }
  return false;
}
function logout(){location.reload()}
function show(name){
  ["dash","dev","term","cfg","set"].forEach(p=>{
    $("page-"+p).classList.toggle("hidden", p!==name);
    $("nav-"+p).classList.toggle("active", p===name);
  });
}
function banner(el, msg, ok){
  el.innerHTML = msg ? `<div class="banner ${ok?"ok":"error"}">${msg}</div>` : "";
}
async function discover(){
  const r = await fetch("/api/discover");
  const d = await r.json();
  banner($("dashMsg"), d.message, !d.error);
  banner($("devMsg"), d.message, !d.error);
  devices = d.devices||[];
  $("c-total").textContent = devices.length;
  $("c-up").textContent = devices.filter(x=>x.status==="started").length;
  $("c-down").textContent = devices.filter(x=>x.status!=="started").length;
  $("c-abs").textContent = 0;
  $("devs").innerHTML = devices.length? devices.map(x=>`
    <tr>
      <td>${x.name}</td><td>${x.node_type||"-"}</td>
      <td><span class="pill ${x.status}">${x.status}</span></td>
      <td dir="ltr">${x.console_host}:${x.console_port||"-"}</td>
      <td class="actions"><a href="#" onclick="openTerm('${x.node_id}');return false">طرفية</a></td>
    </tr>`).join("") : `<tr><td colspan="5">لا توجد أجهزة. شغّل GNS3 ثم اضغط اكتشاف.</td></tr>`;
  $("devsel").innerHTML = devices.map(x=>`<option value="${x.node_id}">${x.name}</option>`).join("");
  $("cfgdev").innerHTML = devices.map(x=>`<option value="${x.node_id}">${x.name}</option>`).join("");
  renderLogs();
}
function openTerm(id){
  $("devsel").value = id;
  show("term");
}
function renderLogs(){
  $("logs").innerHTML = logs.length? logs.map(x=>`<tr><td>${x.name}</td><td dir="ltr">${x.command}</td><td>${x.status}</td></tr>`).join("") : `<tr><td colspan="3">لا توجد أوامر بعد</td></tr>`;
}
async function execCmd(e){
  e.preventDefault();
  const node_id=$("devsel").value, command=$("cmd").value;
  const r = await fetch("/api/exec",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({node_id,command})});
  const d = await r.json();
  const name = (devices.find(x=>x.node_id===node_id)||{}).name||"-";
  if(d.error){
    $("out").textContent = d.error;
    logs.unshift({name,command,status:"error"});
  } else {
    $("out").textContent = d.output||"لا يوجد ناتج";
    logs.unshift({name,command,status:"ok"});
  }
  renderLogs();
  return false;
}
async function postJob(path, body){
  const r = await fetch(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const d = await r.json();
  const text = d.output || d.error || "";
  $("cfgout").textContent = text;
  banner($("cfgMsg"), d.error ? d.error : "تم التنفيذ", !d.error);
  const name = (devices.find(x=>x.node_id===body.node_id)||{}).name||"-";
  logs.unshift({name, command: (d.commands||[]).join(" ; "), status: d.error?"error":"ok"});
  renderLogs();
  return false;
}
function setIp(e){
  e.preventDefault();
  return postJob("/api/set-ip", {node_id:$("cfgdev").value, interface:$("iface").value, ip:$("ipaddr").value, mask:$("mask").value});
}
function setVlan(e){
  e.preventDefault();
  return postJob("/api/vlan", {node_id:$("cfgdev").value, vlan_id:Number($("vlanid").value), name:$("vlanname").value, interface:$("vlanif").value});
}
function saveCfg(){
  return postJob("/api/save", {node_id:$("cfgdev").value});
}
function doBackup(){
  return postJob("/api/backup", {node_id:$("cfgdev").value});
}
async function saveSet(e){
  e.preventDefault();
  await fetch("/api/settings",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({host:$("host").value,port:Number($("port").value)})});
  banner($("dashMsg"), "تم حفظ إعدادات GNS3", true);
  show("dash");
  discover();
  return false;
}
</script>
</body>
</html>
"""

settings = {"host": "127.0.0.1", "port": 3080}


def gns3_base():
    return f"http://{settings['host']}:{settings['port']}"


def gns3_get(path):
    r = httpx.get(gns3_base() + path, timeout=5)
    r.raise_for_status()
    return r.json()


def console_exec(host, port, command, timeout=12):
    return console_exec_many(host, port, [command], timeout=timeout)


def console_exec_many(host, port, commands, timeout=12):
    s = socket.create_connection((host, port), timeout=timeout)
    s.settimeout(timeout)
    try:
        chunks = []
        s.sendall(b"\r\n")
        for command in commands:
            s.sendall(command.encode() + b"\r\n")
            data = b""
            while True:
                try:
                    chunk = s.recv(4096)
                except socket.timeout:
                    break
                if not chunk:
                    break
                data += chunk
                if (b"#" in chunk or b">" in chunk) and len(data) > 8:
                    break
            chunks.append(data.decode("utf-8", "replace"))
        return "\n".join(chunks)
    finally:
        s.close()


def _node(body):
    projects = gns3_get("/v2/projects")
    opened = [p for p in projects if p.get("status") == "opened"][0]
    nodes = gns3_get(f"/v2/projects/{opened['project_id']}/nodes")
    node = next(n for n in nodes if n.get("node_id") == body["node_id"])
    host = node.get("console_host") or settings["host"]
    port = node.get("console")
    if not port:
        raise ValueError("الجهاز ليس له منفذ Console")
    return host, port, node.get("name")


@app.get("/", response_class=HTMLResponse)
def home():
    return HTML


@app.put("/api/settings")
def put_settings(body: dict):
    settings["host"] = body.get("host") or "127.0.0.1"
    settings["port"] = int(body.get("port") or 3080)
    return settings


@app.get("/api/discover")
def discover():
    try:
        projects = gns3_get("/v2/projects")
        opened = [p for p in projects if p.get("status") == "opened"]
        if not opened:
            return {"error": True, "message": "افتح مشروع في GNS3 أولاً", "devices": []}
        project = opened[0]
        nodes = gns3_get(f"/v2/projects/{project['project_id']}/nodes")
        devices = []
        for node in nodes:
            devices.append(
                {
                    "node_id": node.get("node_id"),
                    "name": node.get("name"),
                    "node_type": node.get("node_type"),
                    "status": node.get("status"),
                    "console_host": node.get("console_host") or settings["host"],
                    "console_port": node.get("console"),
                }
            )
        return {
            "error": False,
            "message": f"متصل بـ {gns3_base()} — مشروع {project['name']}",
            "devices": devices,
        }
    except Exception as exc:
        return {"error": True, "message": f"GNS3 غير متاح على {gns3_base()}: {exc}", "devices": []}


@app.post("/api/exec")
def exec_cmd(body: dict):
    try:
        host, port, _ = _node(body)
        return {"output": console_exec(host, port, body["command"])}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/set-ip")
def set_ip(body: dict):
    try:
        host, port, _ = _node(body)
        iface = body["interface"]
        ip = body["ip"]
        mask = body["mask"]
        commands = [
            "configure terminal",
            f"interface {iface}",
            f"ip address {ip} {mask}",
            "no shutdown",
            "end",
        ]
        return {"commands": commands, "output": console_exec_many(host, port, commands)}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/vlan")
def create_vlan(body: dict):
    try:
        host, port, _ = _node(body)
        vlan_id = body["vlan_id"]
        name = body.get("name")
        iface = body.get("interface")
        commands = ["configure terminal", f"vlan {vlan_id}"]
        if name:
            commands.append(f"name {name}")
        commands.append("exit")
        if iface:
            commands.extend(
                [
                    f"interface {iface}",
                    "switchport mode access",
                    f"switchport access vlan {vlan_id}",
                ]
            )
        commands.append("end")
        return {"commands": commands, "output": console_exec_many(host, port, commands)}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/save")
def save_cfg(body: dict):
    try:
        host, port, _ = _node(body)
        commands = ["write memory"]
        return {"commands": commands, "output": console_exec_many(host, port, commands)}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/backup")
def backup(body: dict):
    try:
        host, port, _ = _node(body)
        commands = ["terminal length 0", "show running-config"]
        return {"commands": commands, "output": console_exec_many(host, port, commands, timeout=20)}
    except Exception as exc:
        return {"error": str(exc)}
