from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import httpx
import socket
import uuid

GNS3 = "http://127.0.0.1:3080"
app = FastAPI()

HTML = r"""
<!doctype html>
<html lang="ar">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>منصة أتمتة الشبكة — المرحلة 3</title>
<style>
:root{--bg:#07111f;--panel:#0f1c2e;--card:#15263d;--line:#274060;--text:#e8f1ff;--muted:#93a7c2;--accent:#3ee0c1;--danger:#ff6b7a}
*{box-sizing:border-box}
html,body,#root{margin:0;min-height:100%}
body{font-family:"Segoe UI",Tahoma,sans-serif;background:radial-gradient(circle at top right,#123154,var(--bg) 40%);color:var(--text);direction:rtl}
a{color:var(--accent);text-decoration:none}
.shell{display:grid;grid-template-columns:240px 1fr;min-height:100vh}
.sidebar{background:#0b1726;border-left:1px solid var(--line);padding:24px 18px;display:flex;flex-direction:column;gap:24px}
.brand{display:flex;gap:12px;align-items:center}
.brand-mark{width:42px;height:42px;display:grid;place-items:center;border-radius:12px;background:var(--accent);color:#04221b;font-weight:800}
.brand small{display:block;color:var(--muted)}
nav{display:flex;flex-direction:column;gap:8px}
nav a,button,.logout{border:0;border-radius:10px;padding:10px 12px;color:var(--text);background:transparent;cursor:pointer;font:inherit;text-align:right}
nav a.active,button{background:var(--accent);color:#04221b;font-weight:700}
.logout{margin-top:auto;background:#2a3344;color:#fff}
.content{padding:32px}
.page-head{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}
.card,.table-wrap,.stats article,.terminal,.topo-wrap{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px}
label{display:flex;flex-direction:column;gap:6px;margin-bottom:12px;color:var(--muted)}
input,select{background:#0d1a2b;border:1px solid var(--line);color:var(--text);border-radius:8px;padding:10px}
.banner{padding:12px 14px;border-radius:10px;margin-bottom:16px}
.banner.error{background:#3a1820;color:#ffd5da}
.banner.ok{background:#12362f;color:#c8fff4}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}
.stats strong{display:block;font-size:32px}
.table-wrap{overflow:auto;padding:0}
table{width:100%;border-collapse:collapse}
th,td{padding:12px;border-bottom:1px solid var(--line);text-align:right}
.pill{padding:4px 8px;border-radius:999px;background:#334155}
.pill.started,.pill.up{background:#14532d}
.pill.stopped,.pill.down,.pill.absent{background:#7f1d1d}
.terminal{min-height:220px;background:#071018;font-family:ui-monospace,Menlo,monospace;white-space:pre-wrap}
.login-wrap{min-height:100vh;display:grid;place-items:center}
.login-card{width:380px}
.muted{color:var(--muted)}
.actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.hidden{display:none}
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.phase{display:inline-block;background:#14532d;color:#c8fff4;border-radius:999px;padding:2px 10px;font-size:12px;margin-top:6px}
.topo{width:100%;min-height:420px;background:#071018}
.topo-link{stroke:#3ee0c1;stroke-width:2}
.topo-name{fill:#e8f1ff;font-size:12px;font-weight:700}
.topo-meta{fill:#93a7c2;font-size:10px}
.topo-box{fill:#15263d;stroke:#274060}
.topo-box.started,.topo-box.up{stroke:#3ee0c1}
.topo-box.stopped,.topo-box.down{stroke:#ff6b7a}
.topo-box.selected{fill:#1d3b5c}
.topo-node{cursor:pointer}
.check-list{display:flex;flex-direction:column;gap:6px;margin-bottom:12px}
.check-row{flex-direction:row;align-items:center;gap:8px}
.check-row input{width:auto}
@media(max-width:900px){.grid-2,.shell,.stats{grid-template-columns:1fr}}
</style>
</head>
<body>
<div id="login" class="login-wrap">
  <form class="card login-card" onsubmit="return doLogin(event)">
    <h1>منصة أتمتة الشبكة</h1>
    <p class="muted">المرحلة 3 — تحكم في اللاب والتوبولوجي والبلاي بوكس</p>
    <span class="phase">Phase 3</span>
    <label>اسم المستخدم<input id="user" dir="ltr" value="admin"></label>
    <label>كلمة المرور<input id="pass" type="password" dir="ltr" value="admin"></label>
    <div id="loginErr" class="banner error hidden"></div>
    <button type="submit">دخول</button>
  </form>
</div>
<div id="app" class="shell hidden">
  <aside class="sidebar">
    <div class="brand">
      <span class="brand-mark">NAP</span>
      <div><strong>أتمتة الشبكة</strong><small>مرحلة 3 · GNS3</small></div>
    </div>
    <nav>
      <a href="#" id="nav-dash" class="active" onclick="show('dash');return false">لوحة التحكم</a>
      <a href="#" id="nav-dev" onclick="show('dev');return false">الأجهزة</a>
      <a href="#" id="nav-topo" onclick="show('topo');loadTopo();return false">التوبولوجي</a>
      <a href="#" id="nav-term" onclick="show('term');return false">طرفية</a>
      <a href="#" id="nav-cfg" onclick="show('cfg');return false">الكونفيج</a>
      <a href="#" id="nav-pb" onclick="show('pb');return false">البلاي بوكس</a>
      <a href="#" id="nav-logs" onclick="show('logs');renderLogsPage();return false">السجل</a>
      <a href="#" id="nav-users" onclick="show('users');loadUsers();return false">المستخدمون</a>
      <a href="#" id="nav-set" onclick="show('set');return false">إعدادات GNS3</a>
    </nav>
    <button class="logout" type="button" onclick="logout()">خروج</button>
  </aside>
  <main class="content">
    <section id="page-dash">
      <header class="page-head">
        <h1>لوحة التحكم <span class="phase">Phase 3</span></h1>
        <button type="button" onclick="discover()">اكتشاف أجهزة GNS3</button>
      </header>
      <div id="dashMsg"></div>
      <div class="stats">
        <article><span>الأجهزة</span><strong id="c-total">0</strong></article>
        <article><span>تعمل</span><strong id="c-up">0</strong></article>
        <article><span>متوقفة</span><strong id="c-down">0</strong></article>
        <article><span>غائبة</span><strong id="c-abs">0</strong></article>
      </div>
      <h2>آخر الأوامر</h2>
      <div class="table-wrap">
        <table>
          <thead><tr><th>الجهاز</th><th>الأمر</th><th>الحالة</th></tr></thead>
          <tbody id="logs"></tbody>
        </table>
      </div>
    </section>
    <section id="page-dev" class="hidden">
      <header class="page-head">
        <h1>الأجهزة</h1>
        <button type="button" onclick="discover()">اكتشاف</button>
      </header>
      <div id="devMsg"></div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>الاسم</th><th>النوع</th><th>الحالة</th><th>Console</th><th></th></tr></thead>
          <tbody id="devs"></tbody>
        </table>
      </div>
    </section>
    <section id="page-topo" class="hidden">
      <header class="page-head">
        <h1>التوبولوجي</h1>
        <button type="button" onclick="loadTopo()">تحديث</button>
      </header>
      <div id="topoMsg"></div>
      <div class="topo-wrap" id="topoWrap"><p class="muted">اضغط تحديث لرسم المشروع الحالي.</p></div>
      <article class="card hidden" id="topoSel"></article>
    </section>
    <section id="page-term" class="hidden">
      <header class="page-head"><h1>طرفية</h1></header>
      <form class="card" onsubmit="return execCmd(event)">
        <label>الجهاز<select id="devsel"></select></label>
        <label>الأمر<input id="cmd" dir="ltr" value="show ip interface brief"></label>
        <button type="submit">تنفيذ</button>
      </form>
      <pre class="terminal" id="out" dir="ltr">الناتج سيظهر هنا</pre>
    </section>
    <section id="page-cfg" class="hidden">
      <header class="page-head"><h1>تغيير الكونفيج</h1></header>
      <div id="cfgMsg"></div>
      <div class="grid-2">
        <form class="card" onsubmit="return setIp(event)">
          <h2>تغيير IP</h2>
          <label>الجهاز<select id="cfgdev"></select></label>
          <label>الواجهة<input id="iface" dir="ltr" value="GigabitEthernet0/0"></label>
          <label>IP<input id="ipaddr" dir="ltr" value="192.168.1.1"></label>
          <label>الماسك<input id="mask" dir="ltr" value="255.255.255.0"></label>
          <button type="submit">تطبيق IP</button>
        </form>
        <form class="card" onsubmit="return setVlan(event)">
          <h2>إنشاء VLAN</h2>
          <label>رقم VLAN<input id="vlanid" dir="ltr" type="number" value="10"></label>
          <label>الاسم<input id="vlanname" dir="ltr" value="USERS"></label>
          <label>واجهة (اختياري)<input id="vlanif" dir="ltr"></label>
          <button type="submit">إنشاء VLAN</button>
        </form>
        <form class="card" onsubmit="return addRoute(event)">
          <h2>مسار ستاتيك</h2>
          <label>الشبكة<input id="rnet" dir="ltr" value="10.0.0.0"></label>
          <label>الماسك<input id="rmask" dir="ltr" value="255.255.255.0"></label>
          <label>Next-hop<input id="rnh" dir="ltr" value="192.168.1.1"></label>
          <button type="submit">إضافة مسار</button>
        </form>
      </div>
      <div class="page-head">
        <button type="button" onclick="saveCfg()">حفظ الكونفيج</button>
        <button type="button" onclick="doBackup()">Backup</button>
        <button type="button" onclick="showIfaces()">الواجهات</button>
      </div>
      <pre class="terminal" id="cfgout" dir="ltr">الناتج سيظهر هنا</pre>
    </section>
    <section id="page-pb" class="hidden">
      <header class="page-head"><h1>البلاي بوكس</h1></header>
      <div id="pbMsg"></div>
      <form class="card" onsubmit="return runPlaybook(event)">
        <h2>تنفيذ أمر على أجهزة متعددة</h2>
        <label>الأمر<input id="pbcmd" dir="ltr" value="show version"></label>
        <div class="check-list" id="pbdevs"></div>
        <button type="submit">تشغيل</button>
      </form>
      <pre class="terminal" id="pbout" dir="ltr">النتائج ستظهر هنا</pre>
    </section>
    <section id="page-logs" class="hidden">
      <header class="page-head"><h1>سجل الأوامر</h1></header>
      <div class="table-wrap">
        <table>
          <thead><tr><th>الجهاز</th><th>الأمر</th><th>الحالة</th></tr></thead>
          <tbody id="logsPage"></tbody>
        </table>
      </div>
    </section>
    <section id="page-users" class="hidden">
      <header class="page-head"><h1>المستخدمون</h1></header>
      <div id="userMsg"></div>
      <div class="grid-2">
        <form class="card" onsubmit="return addUser(event)">
          <h2>مستخدم جديد</h2>
          <label>اسم المستخدم<input id="newuser" dir="ltr"></label>
          <label>كلمة المرور<input id="newpass" dir="ltr" type="password"></label>
          <label>الدور
            <select id="newrole">
              <option value="operator">operator</option>
              <option value="admin">admin</option>
            </select>
          </label>
          <button type="submit">إنشاء</button>
        </form>
        <div class="table-wrap">
          <table>
            <thead><tr><th>المستخدم</th><th>الدور</th></tr></thead>
            <tbody id="userRows"></tbody>
          </table>
        </div>
      </div>
    </section>
    <section id="page-set" class="hidden">
      <header class="page-head"><h1>إعدادات GNS3</h1></header>
      <form class="card" onsubmit="return saveSet(event)">
        <label>المضيف<input id="host" dir="ltr" value="127.0.0.1"></label>
        <label>المنفذ<input id="port" dir="ltr" type="number" value="3080"></label>
        <button type="submit">حفظ</button>
      </form>
      <p class="muted">المنصة لازم تكون على نفس جهاز GNS3. الافتراضي 127.0.0.1:3080</p>
    </section>
  </main>
</div>
<script>
let devices=[], logs=[], users=[{username:"admin",role:"admin"}], selectedTopo=null;
const PAGES=["dash","dev","topo","term","cfg","pb","logs","users","set"];
function $(id){return document.getElementById(id)}
function doLogin(e){
  e.preventDefault();
  if($("user").value==="admin" && $("pass").value==="admin"){
    $("login").classList.add("hidden");
    $("app").classList.remove("hidden");
    discover();
  } else {
    $("loginErr").textContent="اسم المستخدم أو كلمة المرور غير صحيحة";
    $("loginErr").classList.remove("hidden");
  }
  return false;
}
function logout(){location.reload()}
function show(name){
  PAGES.forEach(p=>{
    $("page-"+p).classList.toggle("hidden", p!==name);
    $("nav-"+p).classList.toggle("active", p===name);
  });
}
function banner(el, msg, ok){
  el.innerHTML = msg ? `<div class="banner ${ok?"ok":"error"}">${msg}</div>` : "";
}
function fillSelects(){
  const opts = devices.map(x=>`<option value="${x.node_id}">${x.name}</option>`).join("");
  $("devsel").innerHTML = opts;
  $("cfgdev").innerHTML = opts;
  $("pbdevs").innerHTML = devices.map(x=>`<label class="check-row"><input type="checkbox" value="${x.node_id}" checked> ${x.name}</label>`).join("");
}
async function discover(){
  const r = await fetch("/api/discover");
  const d = await r.json();
  banner($("dashMsg"), d.message, !d.error);
  banner($("devMsg"), d.message, !d.error);
  devices = d.devices||[];
  $("c-total").textContent = devices.length;
  $("c-up").textContent = devices.filter(x=>x.status==="started"||x.status==="up").length;
  $("c-down").textContent = devices.filter(x=>x.status!=="started"&&x.status!=="up").length;
  $("c-abs").textContent = 0;
  $("devs").innerHTML = devices.length? devices.map(x=>`
    <tr>
      <td>${x.name}</td><td>${x.node_type||"-"}</td>
      <td><span class="pill ${x.status}">${x.status}</span></td>
      <td dir="ltr">${x.console_host}:${x.console_port||"-"}</td>
      <td class="actions">
        <a href="#" onclick="openTerm('${x.node_id}');return false">طرفية</a>
        <button type="button" onclick="nodeAct('${x.node_id}','start')">تشغيل</button>
        <button type="button" onclick="nodeAct('${x.node_id}','stop')">إيقاف</button>
      </td>
    </tr>`).join("") : `<tr><td colspan="5">لا توجد أجهزة. شغّل GNS3 ثم اضغط اكتشاف.</td></tr>`;
  fillSelects();
  renderLogs();
}
function openTerm(id){
  $("devsel").value = id;
  show("term");
}
function renderLogs(){
  const html = logs.length? logs.map(x=>`<tr><td>${x.name}</td><td dir="ltr">${x.command}</td><td>${x.status}</td></tr>`).join("") : `<tr><td colspan="3">لا توجد أوامر بعد</td></tr>`;
  $("logs").innerHTML = html;
}
function renderLogsPage(){
  $("logsPage").innerHTML = logs.length? logs.map(x=>`<tr><td>${x.name}</td><td dir="ltr">${x.command}</td><td>${x.status}</td></tr>`).join("") : `<tr><td colspan="3">لا توجد سجلات</td></tr>`;
}
async function nodeAct(node_id, action){
  const r = await fetch("/api/node/"+action,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({node_id})});
  const d = await r.json();
  banner($("devMsg"), d.error||("تم "+action), !d.error);
  await discover();
}
async function execCmd(e){
  e.preventDefault();
  const node_id=$("devsel").value, command=$("cmd").value;
  const r = await fetch("/api/exec",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({node_id,command})});
  const d = await r.json();
  const name = (devices.find(x=>x.node_id===node_id)||{}).name||"-";
  if(d.error){
    $("out").textContent = d.error;
    logs.unshift({name,command,status:"error"});
  } else {
    $("out").textContent = d.output||"لا يوجد ناتج";
    logs.unshift({name,command,status:"ok"});
  }
  renderLogs();
  return false;
}
async function postJob(path, body){
  const r = await fetch(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const d = await r.json();
  const text = d.output || d.error || "";
  $("cfgout").textContent = text;
  banner($("cfgMsg"), d.error ? d.error : "تم التنفيذ", !d.error);
  const name = (devices.find(x=>x.node_id===body.node_id)||{}).name||"-";
  logs.unshift({name, command: (d.commands||[]).join(" ; "), status: d.error?"error":"ok"});
  renderLogs();
  return false;
}
function setIp(e){
  e.preventDefault();
  return postJob("/api/set-ip", {node_id:$("cfgdev").value, interface:$("iface").value, ip:$("ipaddr").value, mask:$("mask").value});
}
function setVlan(e){
  e.preventDefault();
  return postJob("/api/vlan", {node_id:$("cfgdev").value, vlan_id:Number($("vlanid").value), name:$("vlanname").value, interface:$("vlanif").value});
}
function addRoute(e){
  e.preventDefault();
  return postJob("/api/static-route", {node_id:$("cfgdev").value, network:$("rnet").value, mask:$("rmask").value, next_hop:$("rnh").value});
}
function saveCfg(){
  return postJob("/api/save", {node_id:$("cfgdev").value});
}
function doBackup(){
  return postJob("/api/backup", {node_id:$("cfgdev").value});
}
function showIfaces(){
  return postJob("/api/interfaces", {node_id:$("cfgdev").value});
}
async function loadTopo(){
  const r = await fetch("/api/topology");
  const d = await r.json();
  if(d.error){ banner($("topoMsg"), d.error, false); return; }
  banner($("topoMsg"), "مشروع "+(d.project_name||""), true);
  const nodes = d.nodes||[];
  if(!nodes.length){ $("topoWrap").innerHTML="<p>لا توجد عقد</p>"; return; }
  const xs=nodes.map(n=>n.x), ys=nodes.map(n=>n.y);
  const minX=Math.min(...xs), minY=Math.min(...ys), maxX=Math.max(...xs), maxY=Math.max(...ys);
  const pad=80;
  const w=Math.max(800, maxX-minX+pad*2);
  const h=Math.max(420, maxY-minY+pad*2);
  const ox=pad-minX, oy=pad-minY;
  const links=(d.links||[]).map(l=>{
    const s=nodes.find(n=>n.id===l.source), t=nodes.find(n=>n.id===l.target);
    if(!s||!t) return "";
    return `<line x1="${s.x+ox}" y1="${s.y+oy}" x2="${t.x+ox}" y2="${t.y+oy}" class="topo-link"/>`;
  }).join("");
  const boxes=nodes.map(n=>{
    const x=n.x+ox, y=n.y+oy;
    return `<g class="topo-node" onclick="pickTopo('${n.id}')">
      <rect x="${x-54}" y="${y-28}" width="108" height="56" rx="12" class="topo-box ${n.status}"/>
      <text x="${x}" y="${y-4}" text-anchor="middle" class="topo-name">${n.name}</text>
      <text x="${x}" y="${y+14}" text-anchor="middle" class="topo-meta">${n.status}</text>
    </g>`;
  }).join("");
  $("topoWrap").innerHTML = `<svg class="topo" viewBox="0 0 ${w} ${h}">${links}${boxes}</svg>`;
  window._topoNodes = nodes;
}
function pickTopo(id){
  const n=(window._topoNodes||[]).find(x=>x.id===id);
  if(!n) return;
  selectedTopo=n;
  $("topoSel").classList.remove("hidden");
  $("topoSel").innerHTML = `<h2>${n.name}</h2><p>الحالة: ${n.status}</p>
    <div class="actions">
      <button type="button" onclick="openTerm('${n.id}')">طرفية</button>
      <button type="button" onclick="nodeAct('${n.id}','start')">تشغيل</button>
      <button type="button" onclick="nodeAct('${n.id}','stop')">إيقاف</button>
    </div>`;
}
async function runPlaybook(e){
  e.preventDefault();
  const command=$("pbcmd").value;
  const ids=[...document.querySelectorAll("#pbdevs input:checked")].map(x=>x.value);
  const r = await fetch("/api/playbook",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({command, node_ids:ids})});
  const d = await r.json();
  if(d.error){ banner($("pbMsg"), d.error, false); return false; }
  banner($("pbMsg"), "تم التنفيذ على "+(d.results||[]).length+" جهاز", true);
  $("pbout").textContent = (d.results||[]).map(x=>"==== "+x.name+" ("+x.status+") ====\n"+(x.output||x.error||"")).join("\n\n");
  (d.results||[]).forEach(x=>logs.unshift({name:x.name, command, status:x.status}));
  renderLogs();
  return false;
}
async function loadUsers(){
  const r = await fetch("/api/users");
  users = await r.json();
  $("userRows").innerHTML = users.map(u=>`<tr><td dir="ltr">${u.username}</td><td>${u.role}</td></tr>`).join("");
}
async function addUser(e){
  e.preventDefault();
  const r = await fetch("/api/users",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:$("newuser").value,password:$("newpass").value,role:$("newrole").value})});
  const d = await r.json();
  banner($("userMsg"), d.error||"تم إنشاء المستخدم", !d.error);
  loadUsers();
  return false;
}
async function saveSet(e){
  e.preventDefault();
  await fetch("/api/settings",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({host:$("host").value,port:Number($("port").value)})});
  banner($("dashMsg"), "تم حفظ إعدادات GNS3", true);
  show("dash");
  discover();
  return false;
}
</script>
</body>
</html>
"""

settings = {"host": "127.0.0.1", "port": 3080}
users = [{"id": str(uuid.uuid4()), "username": "admin", "password": "admin", "role": "admin"}]


def gns3_base():
    return f"http://{settings['host']}:{settings['port']}"


def gns3_get(path):
    r = httpx.get(gns3_base() + path, timeout=5)
    r.raise_for_status()
    return r.json()


def gns3_post(path):
    r = httpx.post(gns3_base() + path, timeout=20)
    r.raise_for_status()
    if not r.content:
        return None
    try:
        return r.json()
    except ValueError:
        return None


def console_exec(host, port, command, timeout=12):
    return console_exec_many(host, port, [command], timeout=timeout)


def console_exec_many(host, port, commands, timeout=12):
    s = socket.create_connection((host, port), timeout=timeout)
    s.settimeout(timeout)
    try:
        chunks = []
        s.sendall(b"\r\n")
        for command in commands:
            s.sendall(command.encode() + b"\r\n")
            data = b""
            while True:
                try:
                    chunk = s.recv(4096)
                except socket.timeout:
                    break
                if not chunk:
                    break
                data += chunk
                if (b"#" in chunk or b">" in chunk) and len(data) > 8:
                    break
            chunks.append(data.decode("utf-8", "replace"))
        return "\n".join(chunks)
    finally:
        s.close()


def _opened_project():
    projects = gns3_get("/v2/projects")
    opened = [p for p in projects if p.get("status") == "opened"]
    if not opened:
        raise ValueError("افتح مشروع في GNS3 أولاً")
    return opened[0]


def _nodes(project_id):
    return gns3_get(f"/v2/projects/{project_id}/nodes")


def _node(body):
    project = _opened_project()
    nodes = _nodes(project["project_id"])
    node = next(n for n in nodes if n.get("node_id") == body["node_id"])
    host = node.get("console_host") or settings["host"]
    port = node.get("console")
    if not port:
        raise ValueError("الجهاز ليس له منفذ Console")
    return host, port, node.get("name"), project, node


@app.get("/", response_class=HTMLResponse)
def home():
    return HTML


@app.put("/api/settings")
def put_settings(body: dict):
    settings["host"] = body.get("host") or "127.0.0.1"
    settings["port"] = int(body.get("port") or 3080)
    return settings


@app.get("/api/discover")
def discover():
    try:
        project = _opened_project()
        nodes = _nodes(project["project_id"])
        devices = []
        for node in nodes:
            devices.append(
                {
                    "node_id": node.get("node_id"),
                    "name": node.get("name"),
                    "node_type": node.get("node_type"),
                    "status": node.get("status"),
                    "console_host": node.get("console_host") or settings["host"],
                    "console_port": node.get("console"),
                    "x": node.get("x") or 0,
                    "y": node.get("y") or 0,
                }
            )
        return {
            "error": False,
            "message": f"متصل بـ {gns3_base()} — مشروع {project['name']} — المرحلة 3",
            "devices": devices,
        }
    except Exception as exc:
        return {"error": True, "message": f"GNS3 غير متاح على {gns3_base()}: {exc}", "devices": []}


@app.get("/api/topology")
def topology():
    try:
        project = _opened_project()
        nodes = _nodes(project["project_id"])
        links = gns3_get(f"/v2/projects/{project['project_id']}/links")
        out_nodes = [
            {
                "id": n.get("node_id"),
                "name": n.get("name"),
                "status": n.get("status"),
                "x": n.get("x") or 0,
                "y": n.get("y") or 0,
            }
            for n in nodes
        ]
        out_links = []
        for link in links:
            pair = link.get("nodes") or []
            if len(pair) < 2:
                continue
            out_links.append(
                {
                    "id": link.get("link_id"),
                    "source": pair[0].get("node_id"),
                    "target": pair[1].get("node_id"),
                }
            )
        return {"project_name": project.get("name"), "nodes": out_nodes, "links": out_links}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/node/{action}")
def node_action(action: str, body: dict):
    try:
        if action not in {"start", "stop", "reload"}:
            return {"error": "إجراء غير صالح"}
        project = _opened_project()
        path = f"/v2/projects/{project['project_id']}/nodes/{body['node_id']}/{action}"
        gns3_post(path)
        return {"ok": True, "action": action}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/exec")
def exec_cmd(body: dict):
    try:
        host, port, _, _, _ = _node(body)
        return {"output": console_exec(host, port, body["command"])}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/playbook")
def playbook(body: dict):
    try:
        project = _opened_project()
        nodes = _nodes(project["project_id"])
        wanted = set(body.get("node_ids") or [])
        command = body.get("command") or "show version"
        results = []
        for node in nodes:
            if wanted and node.get("node_id") not in wanted:
                continue
            host = node.get("console_host") or settings["host"]
            port = node.get("console")
            name = node.get("name")
            if not port:
                results.append({"name": name, "status": "error", "error": "لا يوجد Console"})
                continue
            try:
                output = console_exec(host, port, command)
                results.append({"name": name, "status": "ok", "output": output})
            except Exception as exc:
                results.append({"name": name, "status": "error", "error": str(exc)})
        return {"results": results}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/set-ip")
def set_ip(body: dict):
    try:
        host, port, _, _, _ = _node(body)
        iface = body["interface"]
        ip = body["ip"]
        mask = body["mask"]
        commands = [
            "configure terminal",
            f"interface {iface}",
            f"ip address {ip} {mask}",
            "no shutdown",
            "end",
        ]
        return {"commands": commands, "output": console_exec_many(host, port, commands)}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/vlan")
def create_vlan(body: dict):
    try:
        host, port, _, _, _ = _node(body)
        vlan_id = body["vlan_id"]
        name = body.get("name")
        iface = body.get("interface")
        commands = ["configure terminal", f"vlan {vlan_id}"]
        if name:
            commands.append(f"name {name}")
        commands.append("exit")
        if iface:
            commands.extend(
                [
                    f"interface {iface}",
                    "switchport mode access",
                    f"switchport access vlan {vlan_id}",
                ]
            )
        commands.append("end")
        return {"commands": commands, "output": console_exec_many(host, port, commands)}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/static-route")
def static_route(body: dict):
    try:
        host, port, _, _, _ = _node(body)
        commands = [
            "configure terminal",
            f"ip route {body['network']} {body['mask']} {body['next_hop']}",
            "end",
        ]
        return {"commands": commands, "output": console_exec_many(host, port, commands)}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/interfaces")
def interfaces(body: dict):
    try:
        host, port, _, _, _ = _node(body)
        commands = ["terminal length 0", "show ip interface brief"]
        return {"commands": commands, "output": console_exec_many(host, port, commands)}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/save")
def save_cfg(body: dict):
    try:
        host, port, _, _, _ = _node(body)
        commands = ["write memory"]
        return {"commands": commands, "output": console_exec_many(host, port, commands)}
    except Exception as exc:
        return {"error": str(exc)}


@app.post("/api/backup")
def backup(body: dict):
    try:
        host, port, _, _, _ = _node(body)
        commands = ["terminal length 0", "show running-config"]
        return {"commands": commands, "output": console_exec_many(host, port, commands, timeout=20)}
    except Exception as exc:
        return {"error": str(exc)}


@app.get("/api/users")
def list_users():
    return [{"username": u["username"], "role": u["role"]} for u in users]


@app.post("/api/users")
def create_user(body: dict):
    username = (body.get("username") or "").strip()
    if not username:
        return {"error": "اسم المستخدم مطلوب"}
    if any(u["username"] == username for u in users):
        return {"error": "اسم المستخدم موجود"}
    users.append(
        {
            "id": str(uuid.uuid4()),
            "username": username,
            "password": body.get("password") or "",
            "role": body.get("role") or "operator",
        }
    )
    return {"ok": True}
