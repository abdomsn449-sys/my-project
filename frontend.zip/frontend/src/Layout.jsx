import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { clearToken } from "./api";

export default function Layout() {
  const navigate = useNavigate();
  function logout() {
    clearToken();
    navigate("/login");
  }
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark">NAP</span>
          <div>
            <strong>أتمتة الشبكة</strong>
            <small>مختبر GNS3</small>
          </div>
        </div>
        <nav>
          <NavLink to="/" end>
            لوحة التحكم
          </NavLink>
          <NavLink to="/devices">الأجهزة</NavLink>
          <NavLink to="/configure">الكونفيج</NavLink>
          <NavLink to="/settings">إعدادات GNS3</NavLink>
        </nav>
        <button className="logout" onClick={logout} type="button">
          خروج
        </button>
      </aside>
      <main className="content">
        <Outlet />
      </main>
    </div>
  );
}
