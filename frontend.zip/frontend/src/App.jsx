import { Navigate, Route, Routes } from "react-router-dom";
import { getToken } from "./api";
import Layout from "./Layout.jsx";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Devices from "./pages/Devices.jsx";
import DeviceDetail from "./pages/DeviceDetail.jsx";
import Terminal from "./pages/Terminal.jsx";
import Settings from "./pages/Settings.jsx";
import Configure from "./pages/Configure.jsx";
import Topology from "./pages/Topology.jsx";
import Playbooks from "./pages/Playbooks.jsx";
import Logs from "./pages/Logs.jsx";
import Users from "./pages/Users.jsx";

function Private({ children }) {
  if (!getToken()) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/"
        element={
          <Private>
            <Layout />
          </Private>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="devices" element={<Devices />} />
        <Route path="devices/:id" element={<DeviceDetail />} />
        <Route path="devices/:id/terminal" element={<Terminal />} />
        <Route path="configure" element={<Configure />} />
        <Route path="topology" element={<Topology />} />
        <Route path="playbooks" element={<Playbooks />} />
        <Route path="logs" element={<Logs />} />
        <Route path="users" element={<Users />} />
        <Route path="settings" element={<Settings />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
