import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";

export default function Devices() {
  const [devices, setDevices] = useState([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      setDevices(await api("/api/devices"));
      setError("");
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function discover() {
    setBusy(true);
    try {
      await api("/api/gns3/discover", { method: "POST" });
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section>
      <header className="page-head">
        <h1>الأجهزة</h1>
        <button onClick={discover} disabled={busy} type="button">
          {busy ? "جاري الاكتشاف..." : "اكتشاف"}
        </button>
      </header>
      {error ? <div className="banner error">{error}</div> : null}
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>الاسم</th>
              <th>الدور</th>
              <th>المصنّع</th>
              <th>الحالة</th>
              <th>Console</th>
              <th>IP الإدارة</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {devices.length === 0 ? (
              <tr>
                <td colSpan="7">لا توجد أجهزة. شغّل GNS3 ثم اضغط اكتشاف.</td>
              </tr>
            ) : (
              devices.map((device) => (
                <tr key={device.id}>
                  <td>{device.name}</td>
                  <td>{device.role}</td>
                  <td dir="ltr">{device.vendor}</td>
                  <td>
                    <span className={`pill ${device.status}`}>{device.status}</span>
                  </td>
                  <td dir="ltr">
                    {device.console_host}:{device.console_port || "-"}
                  </td>
                  <td dir="ltr">{device.mgmt_ip || "-"}</td>
                  <td className="actions">
                    <Link to={`/devices/${device.id}`}>تفاصيل</Link>
                    <Link to={`/devices/${device.id}/terminal`}>طرفية</Link>
                    <Link to="/configure">كونفيج</Link>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}
