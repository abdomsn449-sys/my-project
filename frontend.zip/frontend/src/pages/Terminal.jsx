import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api } from "../api";

const DANGEROUS = [
  "reload",
  "reboot",
  "erase startup-config",
  "write erase",
  "request system reboot",
  "request system zeroize",
];

export default function Terminal() {
  const { id } = useParams();
  const [device, setDevice] = useState(null);
  const [command, setCommand] = useState("show ip interface brief");
  const [channel, setChannel] = useState("console");
  const [output, setOutput] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api(`/api/devices/${id}`)
      .then(setDevice)
      .catch((err) => setError(err.message));
  }, [id]);

  async function run(confirm = false) {
    setBusy(true);
    setError("");
    try {
      const data = await api(`/api/devices/${id}/exec`, {
        method: "POST",
        body: JSON.stringify({ command, channel, confirm }),
      });
      setOutput(data.output || data.error_message || "");
    } catch (err) {
      if (err.status === 409 && err.data?.detail?.status === "blocked") {
        if (window.confirm("هذا أمر خطير. هل تريد التنفيذ؟")) {
          setBusy(false);
          return run(true);
        }
      }
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  function onSubmit(event) {
    event.preventDefault();
    const needsConfirm = DANGEROUS.includes(command.trim().toLowerCase());
    run(needsConfirm ? false : false);
  }

  if (!device) return <p>{error || "جاري التحميل..."}</p>;

  return (
    <section>
      <header className="page-head">
        <h1>طرفية {device.name}</h1>
        <Link to={`/devices/${id}`}>رجوع</Link>
      </header>
      {error ? <div className="banner error">{error}</div> : null}
      <form className="card" onSubmit={onSubmit}>
        <label>
          القناة
          <select value={channel} onChange={(e) => setChannel(e.target.value)}>
            <option value="console">Console</option>
            <option value="ssh">SSH</option>
          </select>
        </label>
        <label>
          الأمر
          <input dir="ltr" value={command} onChange={(e) => setCommand(e.target.value)} />
        </label>
        <button type="submit" disabled={busy}>
          {busy ? "جاري التنفيذ..." : "تنفيذ"}
        </button>
      </form>
      <pre className="terminal" dir="ltr">
        {output || "الناتج سيظهر هنا"}
      </pre>
    </section>
  );
}
