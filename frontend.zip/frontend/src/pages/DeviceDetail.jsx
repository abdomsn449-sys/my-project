import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api } from "../api";

export default function DeviceDetail() {
  const { id } = useParams();
  const [device, setDevice] = useState(null);
  const [logs, setLogs] = useState([]);
  const [form, setForm] = useState({
    mgmt_ip: "",
    ssh_port: 22,
    ssh_username: "",
    ssh_password: "",
    vendor: "cisco",
  });
  const [probe, setProbe] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function load() {
    const [dev, history] = await Promise.all([
      api(`/api/devices/${id}`),
      api(`/api/logs?device_id=${id}`),
    ]);
    setDevice(dev);
    setLogs(history);
    setForm({
      mgmt_ip: dev.mgmt_ip || "",
      ssh_port: dev.ssh_port || 22,
      ssh_username: dev.ssh_username || "",
      ssh_password: "",
      vendor: dev.vendor,
    });
  }

  useEffect(() => {
    load().catch((err) => setError(err.message));
  }, [id]);

  async function save(event) {
    event.preventDefault();
    setError("");
    try {
      const payload = {
        mgmt_ip: form.mgmt_ip,
        ssh_port: Number(form.ssh_port),
        ssh_username: form.ssh_username,
        vendor: form.vendor,
      };
      if (form.ssh_password) payload.ssh_password = form.ssh_password;
      setDevice(await api(`/api/devices/${id}`, { method: "PATCH", body: JSON.stringify(payload) }));
      setMessage("تم حفظ بيانات SSH");
    } catch (err) {
      setError(err.message);
    }
  }

  async function test() {
    try {
      setProbe(await api(`/api/devices/${id}/connect-test`, { method: "POST" }));
    } catch (err) {
      setError(err.message);
    }
  }

  if (!device) return <p>{error || "جاري التحميل..."}</p>;

  return (
    <section>
      <header className="page-head">
        <h1>{device.name}</h1>
        <Link className="button-link" to={`/devices/${id}/terminal`}>
          فتح الطرفية
        </Link>
      </header>
      {error ? <div className="banner error">{error}</div> : null}
      {message ? <div className="banner ok">{message}</div> : null}
      <div className="grid-2">
        <article className="card">
          <h2>بيانات الجهاز</h2>
          <p>الدور: {device.role}</p>
          <p>
            الحالة: <span className={`pill ${device.status}`}>{device.status}</span>
          </p>
          <p dir="ltr">
            Console: {device.console_host}:{device.console_port || "-"}
          </p>
          <button type="button" onClick={test}>
            اختبار الاتصال
          </button>
          {probe ? (
            <p>
              Console: {probe.console} — SSH: {probe.ssh}
            </p>
          ) : null}
        </article>
        <form className="card" onSubmit={save}>
          <h2>SSH</h2>
          <label>
            المصنّع
            <select value={form.vendor} onChange={(e) => setForm({ ...form, vendor: e.target.value })}>
              <option value="cisco">cisco</option>
              <option value="juniper">juniper</option>
              <option value="unknown">unknown</option>
            </select>
          </label>
          <label>
            IP الإدارة
            <input
              dir="ltr"
              value={form.mgmt_ip}
              onChange={(e) => setForm({ ...form, mgmt_ip: e.target.value })}
            />
          </label>
          <label>
            منفذ SSH
            <input
              dir="ltr"
              type="number"
              value={form.ssh_port}
              onChange={(e) => setForm({ ...form, ssh_port: e.target.value })}
            />
          </label>
          <label>
            المستخدم
            <input
              dir="ltr"
              value={form.ssh_username}
              onChange={(e) => setForm({ ...form, ssh_username: e.target.value })}
            />
          </label>
          <label>
            كلمة المرور
            <input
              dir="ltr"
              type="password"
              value={form.ssh_password}
              onChange={(e) => setForm({ ...form, ssh_password: e.target.value })}
            />
          </label>
          <button type="submit">حفظ</button>
        </form>
      </div>
      <h2>سجل الأوامر</h2>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>القناة</th>
              <th>الأمر</th>
              <th>الحالة</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log) => (
              <tr key={log.id}>
                <td dir="ltr">{log.channel}</td>
                <td dir="ltr">{log.command}</td>
                <td>{log.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
