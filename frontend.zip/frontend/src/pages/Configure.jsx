import { useEffect, useState } from "react";
import { api, getToken } from "../api";

export default function Configure() {
  const [devices, setDevices] = useState([]);
  const [deviceId, setDeviceId] = useState("");
  const [channel, setChannel] = useState("console");
  const [ipForm, setIpForm] = useState({ interface: "GigabitEthernet0/0", ip: "192.168.1.1", mask: "255.255.255.0" });
  const [vlanForm, setVlanForm] = useState({ vlan_id: 10, name: "USERS", interface: "" });
  const [routeForm, setRouteForm] = useState({ network: "10.0.0.0", mask: "24", next_hop: "192.168.1.1" });
  const [output, setOutput] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [backups, setBackups] = useState([]);
  const [busy, setBusy] = useState(false);

  async function load() {
    const list = await api("/api/devices");
    setDevices(list);
    if (!deviceId && list[0]) setDeviceId(list[0].id);
    const history = await api("/api/backups");
    setBackups(history);
  }

  useEffect(() => {
    load().catch((err) => setError(err.message));
  }, []);

  async function run(path, body) {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const data = await api(path, { method: "POST", body: JSON.stringify(body) });
      setOutput(data.output || data.content || "");
      setMessage(data.status === "ok" || data.content ? "تم التنفيذ" : data.error_message || "تم");
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  function download(id) {
    const token = getToken();
    fetch(`/api/backups/${id}/download`, { headers: { Authorization: `Bearer ${token}` } })
      .then((res) => res.blob())
      .then((blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "backup.cfg";
        a.click();
        URL.revokeObjectURL(url);
      });
  }

  return (
    <section>
      <header className="page-head">
        <h1>تغيير الكونفيج</h1>
      </header>
      {error ? <div className="banner error">{error}</div> : null}
      {message ? <div className="banner ok">{message}</div> : null}
      <div className="grid-2">
        <form
          className="card"
          onSubmit={(e) => {
            e.preventDefault();
            run(`/api/devices/${deviceId}/set-ip`, { ...ipForm, channel });
          }}
        >
          <h2>تغيير IP</h2>
          <label>
            الجهاز
            <select value={deviceId} onChange={(e) => setDeviceId(e.target.value)}>
              {devices.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            القناة
            <select value={channel} onChange={(e) => setChannel(e.target.value)}>
              <option value="console">Console</option>
              <option value="ssh">SSH</option>
            </select>
          </label>
          <label>
            الواجهة
            <input dir="ltr" value={ipForm.interface} onChange={(e) => setIpForm({ ...ipForm, interface: e.target.value })} />
          </label>
          <label>
            IP
            <input dir="ltr" value={ipForm.ip} onChange={(e) => setIpForm({ ...ipForm, ip: e.target.value })} />
          </label>
          <label>
            الماسك
            <input dir="ltr" value={ipForm.mask} onChange={(e) => setIpForm({ ...ipForm, mask: e.target.value })} />
          </label>
          <button type="submit" disabled={busy || !deviceId}>
            تطبيق IP
          </button>
        </form>
        <form
          className="card"
          onSubmit={(e) => {
            e.preventDefault();
            run(`/api/devices/${deviceId}/vlan`, {
              vlan_id: Number(vlanForm.vlan_id),
              name: vlanForm.name || null,
              interface: vlanForm.interface || null,
              channel,
            });
          }}
        >
          <h2>إنشاء VLAN</h2>
          <label>
            رقم VLAN
            <input dir="ltr" type="number" value={vlanForm.vlan_id} onChange={(e) => setVlanForm({ ...vlanForm, vlan_id: e.target.value })} />
          </label>
          <label>
            الاسم
            <input dir="ltr" value={vlanForm.name} onChange={(e) => setVlanForm({ ...vlanForm, name: e.target.value })} />
          </label>
          <label>
            واجهة (اختياري)
            <input dir="ltr" value={vlanForm.interface} onChange={(e) => setVlanForm({ ...vlanForm, interface: e.target.value })} />
          </label>
          <button type="submit" disabled={busy || !deviceId}>
            إنشاء VLAN
          </button>
        </form>
        <form
          className="card"
          onSubmit={(e) => {
            e.preventDefault();
            run(`/api/devices/${deviceId}/static-route`, { ...routeForm, channel });
          }}
        >
          <h2>مسار ستاتيك</h2>
          <label>
            الشبكة
            <input dir="ltr" value={routeForm.network} onChange={(e) => setRouteForm({ ...routeForm, network: e.target.value })} />
          </label>
          <label>
            الماسك
            <input dir="ltr" value={routeForm.mask} onChange={(e) => setRouteForm({ ...routeForm, mask: e.target.value })} />
          </label>
          <label>
            Next-hop
            <input dir="ltr" value={routeForm.next_hop} onChange={(e) => setRouteForm({ ...routeForm, next_hop: e.target.value })} />
          </label>
          <button type="submit" disabled={busy || !deviceId}>
            إضافة مسار
          </button>
        </form>
      </div>
      <div className="page-head">
        <button type="button" disabled={busy || !deviceId} onClick={() => run(`/api/devices/${deviceId}/save`, { channel })}>
          حفظ الكونفيج
        </button>
        <button type="button" disabled={busy || !deviceId} onClick={() => run(`/api/devices/${deviceId}/backup`, { channel })}>
          Backup
        </button>
      </div>
      <pre className="terminal" dir="ltr">
        {output || "الناتج سيظهر هنا"}
      </pre>
      <h2>النسخ الاحتياطية</h2>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>الجهاز</th>
              <th>الوقت</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {backups.length === 0 ? (
              <tr>
                <td colSpan="3">لا توجد نسخ بعد</td>
              </tr>
            ) : (
              backups.map((row) => (
                <tr key={row.id}>
                  <td>{row.device_name}</td>
                  <td dir="ltr">{row.created_at}</td>
                  <td>
                    <button type="button" onClick={() => download(row.id)}>
                      تحميل
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}
