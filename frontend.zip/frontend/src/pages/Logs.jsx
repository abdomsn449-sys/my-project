import { useEffect, useState } from "react";
import { api } from "../api";

export default function Logs() {
  const [logs, setLogs] = useState([]);
  const [devices, setDevices] = useState([]);
  const [deviceId, setDeviceId] = useState("");
  const [error, setError] = useState("");

  async function load(id = deviceId) {
    const path = id ? `/api/logs?device_id=${id}` : "/api/logs";
    setLogs(await api(path));
  }

  useEffect(() => {
    Promise.all([api("/api/devices"), load()]).then(([list]) => setDevices(list)).catch((err) => setError(err.message));
  }, []);

  return (
    <section>
      <header className="page-head">
        <h1>سجل الأوامر</h1>
        <label>
          الجهاز
          <select
            value={deviceId}
            onChange={(e) => {
              setDeviceId(e.target.value);
              load(e.target.value).catch((err) => setError(err.message));
            }}
          >
            <option value="">الكل</option>
            {devices.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>
        </label>
      </header>
      {error ? <div className="banner error">{error}</div> : null}
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>الجهاز</th>
              <th>القناة</th>
              <th>الأمر</th>
              <th>الحالة</th>
              <th>الوقت</th>
            </tr>
          </thead>
          <tbody>
            {logs.length === 0 ? (
              <tr>
                <td colSpan="5">لا توجد سجلات</td>
              </tr>
            ) : (
              logs.map((log) => (
                <tr key={log.id}>
                  <td>{log.device_name || "-"}</td>
                  <td dir="ltr">{log.channel}</td>
                  <td dir="ltr">{log.command}</td>
                  <td>{log.status}</td>
                  <td dir="ltr">{log.created_at}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}
