import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      setData(await api("/api/dashboard"));
      setError("");
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function discover() {
    setBusy(true);
    setError("");
    try {
      await api("/api/gns3/discover", { method: "POST" });
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section>
      <header className="page-head">
        <h1>لوحة التحكم</h1>
        <button onClick={discover} disabled={busy} type="button">
          {busy ? "جاري الاكتشاف..." : "اكتشاف أجهزة GNS3"}
        </button>
      </header>
      {error ? <div className="banner error">{error}</div> : null}
      {data ? (
        <>
          <div className={`banner ${data.gns3_reachable ? "ok" : "error"}`}>{data.gns3_message}</div>
          <div className="stats">
            <article>
              <span>الأجهزة</span>
              <strong>{data.total}</strong>
            </article>
            <article>
              <span>تعمل</span>
              <strong>{data.up}</strong>
            </article>
            <article>
              <span>متوقفة</span>
              <strong>{data.down}</strong>
            </article>
            <article>
              <span>غائبة</span>
              <strong>{data.absent}</strong>
            </article>
          </div>
          <h2>آخر الأوامر</h2>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>الجهاز</th>
                  <th>القناة</th>
                  <th>الأمر</th>
                  <th>الحالة</th>
                </tr>
              </thead>
              <tbody>
                {data.recent_logs.length === 0 ? (
                  <tr>
                    <td colSpan="4">لا توجد أوامر بعد</td>
                  </tr>
                ) : (
                  data.recent_logs.map((log) => (
                    <tr key={log.id}>
                      <td>{log.device_name || "-"}</td>
                      <td dir="ltr">{log.channel}</td>
                      <td dir="ltr">{log.command}</td>
                      <td>{log.status}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          <p>
            <Link to="/devices">عرض الأجهزة</Link>
          </p>
        </>
      ) : null}
    </section>
  );
}
