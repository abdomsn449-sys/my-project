import { useEffect, useState } from "react";
import { api } from "../api";

export default function Playbooks() {
  const [devices, setDevices] = useState([]);
  const [selected, setSelected] = useState([]);
  const [command, setCommand] = useState("show version");
  const [name, setName] = useState("show-version");
  const [channel, setChannel] = useState("console");
  const [runs, setRuns] = useState([]);
  const [current, setCurrent] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    const [list, history] = await Promise.all([api("/api/devices"), api("/api/playbooks")]);
    setDevices(list);
    setRuns(history);
    if (selected.length === 0) setSelected(list.map((d) => d.id));
  }

  useEffect(() => {
    load().catch((err) => setError(err.message));
  }, []);

  function toggle(id) {
    setSelected((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]));
  }

  async function run(confirm = false) {
    setBusy(true);
    setError("");
    try {
      const data = await api("/api/playbooks/run", {
        method: "POST",
        body: JSON.stringify({
          name,
          command,
          channel,
          device_ids: selected,
          confirm,
        }),
      });
      setCurrent(data);
      await load();
    } catch (err) {
      if (err.status === 409 && err.data?.detail?.status === "blocked") {
        if (window.confirm("هذا أمر خطير. هل تريد التنفيذ على كل الأجهزة المحددة؟")) {
          setBusy(false);
          return run(true);
        }
      }
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function openRun(id) {
    try {
      setCurrent(await api(`/api/playbooks/${id}`));
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <section>
      <header className="page-head">
        <h1>البلاي بوكس</h1>
      </header>
      {error ? <div className="banner error">{error}</div> : null}
      <div className="grid-2">
        <form
          className="card"
          onSubmit={(e) => {
            e.preventDefault();
            run(false);
          }}
        >
          <h2>تنفيذ أمر على أجهزة متعددة</h2>
          <label>
            الاسم
            <input dir="ltr" value={name} onChange={(e) => setName(e.target.value)} />
          </label>
          <label>
            الأمر
            <input dir="ltr" value={command} onChange={(e) => setCommand(e.target.value)} />
          </label>
          <label>
            القناة
            <select value={channel} onChange={(e) => setChannel(e.target.value)}>
              <option value="console">Console</option>
              <option value="ssh">SSH</option>
            </select>
          </label>
          <div className="check-list">
            {devices.map((device) => (
              <label key={device.id} className="check-row">
                <input
                  type="checkbox"
                  checked={selected.includes(device.id)}
                  onChange={() => toggle(device.id)}
                />
                {device.name}
              </label>
            ))}
          </div>
          <button type="submit" disabled={busy || selected.length === 0}>
            {busy ? "جاري التنفيذ..." : "تشغيل"}
          </button>
        </form>
        <article className="card">
          <h2>آخر التنفيذات</h2>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>الاسم</th>
                  <th>الأمر</th>
                  <th>الحالة</th>
                </tr>
              </thead>
              <tbody>
                {runs.length === 0 ? (
                  <tr>
                    <td colSpan="3">لا توجد تنفيذات بعد</td>
                  </tr>
                ) : (
                  runs.map((row) => (
                    <tr key={row.id}>
                      <td>
                        <button type="button" className="linkish" onClick={() => openRun(row.id)}>
                          {row.name}
                        </button>
                      </td>
                      <td dir="ltr">{row.command}</td>
                      <td>{row.status}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </article>
      </div>
      {current ? (
        <div>
          <h2>
            نتائج {current.name} ({current.status})
          </h2>
          {(current.results || []).map((row) => (
            <article className="card" key={row.id}>
              <h3>
                {row.device_name} — {row.status}
              </h3>
              <pre className="terminal" dir="ltr">
                {row.output || row.error_message || ""}
              </pre>
            </article>
          ))}
        </div>
      ) : null}
    </section>
  );
}
