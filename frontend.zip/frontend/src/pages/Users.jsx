import { useEffect, useState } from "react";
import { api } from "../api";

export default function Users() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ username: "", password: "", role: "operator" });
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function load() {
    setUsers(await api("/api/users"));
  }

  useEffect(() => {
    load().catch((err) => setError(err.message));
  }, []);

  async function createUser(event) {
    event.preventDefault();
    setError("");
    try {
      await api("/api/users", { method: "POST", body: JSON.stringify(form) });
      setMessage("تم إنشاء المستخدم");
      setForm({ username: "", password: "", role: "operator" });
      await load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function changeRole(id, role) {
    setError("");
    try {
      await api(`/api/users/${id}`, { method: "PATCH", body: JSON.stringify({ role }) });
      await load();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <section>
      <header className="page-head">
        <h1>المستخدمون</h1>
      </header>
      {error ? <div className="banner error">{error}</div> : null}
      {message ? <div className="banner ok">{message}</div> : null}
      <div className="grid-2">
        <form className="card" onSubmit={createUser}>
          <h2>مستخدم جديد</h2>
          <label>
            اسم المستخدم
            <input dir="ltr" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
          </label>
          <label>
            كلمة المرور
            <input
              dir="ltr"
              type="password"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
          </label>
          <label>
            الدور
            <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              <option value="operator">operator</option>
              <option value="admin">admin</option>
            </select>
          </label>
          <button type="submit">إنشاء</button>
        </form>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>المستخدم</th>
                <th>الدور</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id}>
                  <td dir="ltr">{user.username}</td>
                  <td>{user.role}</td>
                  <td className="actions">
                    <button type="button" onClick={() => changeRole(user.id, user.role === "admin" ? "operator" : "admin")}>
                      تبديل الدور
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
