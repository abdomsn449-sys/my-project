import { useEffect, useState } from "react";
import { api } from "../api";

export default function Settings() {
  const [form, setForm] = useState({
    protocol: "http",
    host: "127.0.0.1",
    port: 3080,
    username: "",
    password: "",
    project_id: "",
  });
  const [projects, setProjects] = useState([]);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function load() {
    const settings = await api("/api/gns3/settings");
    setForm({
      protocol: settings.protocol,
      host: settings.host,
      port: settings.port,
      username: settings.username || "",
      password: "",
      project_id: settings.project_id || "",
    });
    try {
      setProjects(await api("/api/gns3/projects"));
    } catch (err) {
      setProjects([]);
      setError(err.message);
    }
  }

  useEffect(() => {
    load().catch((err) => setError(err.message));
  }, []);

  async function save(event) {
    event.preventDefault();
    setError("");
    try {
      const payload = { ...form, port: Number(form.port) };
      if (!payload.password) delete payload.password;
      await api("/api/gns3/settings", { method: "PUT", body: JSON.stringify(payload) });
      setMessage("تم حفظ إعدادات GNS3");
      await load();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <section>
      <header className="page-head">
        <h1>إعدادات GNS3</h1>
      </header>
      {error ? <div className="banner error">{error}</div> : null}
      {message ? <div className="banner ok">{message}</div> : null}
      <form className="card" onSubmit={save}>
        <label>
          البروتوكول
          <select value={form.protocol} onChange={(e) => setForm({ ...form, protocol: e.target.value })}>
            <option value="http">http</option>
            <option value="https">https</option>
          </select>
        </label>
        <label>
          المضيف
          <input dir="ltr" value={form.host} onChange={(e) => setForm({ ...form, host: e.target.value })} />
        </label>
        <label>
          المنفذ
          <input
            dir="ltr"
            type="number"
            value={form.port}
            onChange={(e) => setForm({ ...form, port: e.target.value })}
          />
        </label>
        <label>
          المستخدم (اختياري)
          <input
            dir="ltr"
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value })}
          />
        </label>
        <label>
          كلمة المرور
          <input
            dir="ltr"
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
          />
        </label>
        <label>
          المشروع
          <select
            value={form.project_id}
            onChange={(e) => setForm({ ...form, project_id: e.target.value })}
          >
            <option value="">المشروع المفتوح حالياً</option>
            {projects.map((project) => (
              <option key={project.project_id} value={project.project_id}>
                {project.name} ({project.status})
              </option>
            ))}
          </select>
        </label>
        <button type="submit">حفظ</button>
      </form>
    </section>
  );
}
