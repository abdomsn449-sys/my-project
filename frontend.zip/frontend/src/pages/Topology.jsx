import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";

export default function Topology() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      setData(await api("/api/gns3/topology"));
      setError("");
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const layout = useMemo(() => {
    if (!data || data.nodes.length === 0) {
      return { nodes: [], width: 800, height: 420, offsetX: 0, offsetY: 0 };
    }
    const xs = data.nodes.map((n) => n.x);
    const ys = data.nodes.map((n) => n.y);
    const minX = Math.min(...xs);
    const minY = Math.min(...ys);
    const maxX = Math.max(...xs);
    const maxY = Math.max(...ys);
    const pad = 80;
    return {
      nodes: data.nodes,
      width: Math.max(800, maxX - minX + pad * 2),
      height: Math.max(420, maxY - minY + pad * 2),
      offsetX: pad - minX,
      offsetY: pad - minY,
    };
  }, [data]);

  async function act(deviceId, action) {
    setBusy(true);
    setError("");
    try {
      await api(`/api/devices/${deviceId}/${action}`, { method: "POST" });
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section>
      <header className="page-head">
        <h1>التوبولوجي</h1>
        <button type="button" onClick={load} disabled={busy}>
          تحديث
        </button>
      </header>
      {error ? <div className="banner error">{error}</div> : null}
      {data ? <p className="muted">المشروع: {data.project_name || data.project_id}</p> : null}
      <div className="topo-wrap">
        {data && data.nodes.length === 0 ? (
          <p>لا توجد عقد. اكتشف الأجهزة أولاً.</p>
        ) : (
          <svg className="topo" viewBox={`0 0 ${layout.width} ${layout.height}`} role="img">
            {(data?.links || []).map((link) => {
              const source = layout.nodes.find((n) => n.id === link.source);
              const target = layout.nodes.find((n) => n.id === link.target);
              if (!source || !target) return null;
              const x1 = source.x + layout.offsetX;
              const y1 = source.y + layout.offsetY;
              const x2 = target.x + layout.offsetX;
              const y2 = target.y + layout.offsetY;
              return (
                <g key={link.id}>
                  <line x1={x1} y1={y1} x2={x2} y2={y2} className="topo-link" />
                  <text x={(x1 + x2) / 2} y={(y1 + y2) / 2 - 8} className="topo-label">
                    {link.source_label}
                  </text>
                </g>
              );
            })}
            {layout.nodes.map((node) => {
              const x = node.x + layout.offsetX;
              const y = node.y + layout.offsetY;
              const active = selected?.id === node.id;
              return (
                <g key={node.id} className="topo-node" onClick={() => setSelected(node)}>
                  <rect
                    x={x - 54}
                    y={y - 28}
                    width="108"
                    height="56"
                    rx="12"
                    className={`topo-box ${node.status} ${active ? "selected" : ""}`}
                  />
                  <text x={x} y={y - 4} textAnchor="middle" className="topo-name">
                    {node.name}
                  </text>
                  <text x={x} y={y + 14} textAnchor="middle" className="topo-meta">
                    {node.role || node.node_type} · {node.status}
                  </text>
                </g>
              );
            })}
          </svg>
        )}
      </div>
      {selected ? (
        <article className="card">
          <h2>{selected.name}</h2>
          <p>
            الحالة: <span className={`pill ${selected.status}`}>{selected.status}</span>
          </p>
          <p>الدور: {selected.role || "-"}</p>
          <div className="actions">
            {selected.device_id ? (
              <>
                <Link to={`/devices/${selected.device_id}`}>تفاصيل</Link>
                <Link to={`/devices/${selected.device_id}/terminal`}>طرفية</Link>
                <button type="button" disabled={busy} onClick={() => act(selected.device_id, "start")}>
                  تشغيل
                </button>
                <button type="button" disabled={busy} onClick={() => act(selected.device_id, "stop")}>
                  إيقاف
                </button>
              </>
            ) : (
              <p className="muted">العقدة غير مستوردة بعد. اضغط اكتشاف.</p>
            )}
          </div>
        </article>
      ) : null}
    </section>
  );
}
