# Network Automation Platform — Phase 1: GNS3 Lab

Date: 2026-09-07
Status: Approved for implementation planning
Scope: First delivery only (GNS3 discovery + console/SSH command execution)

## 1. Goal

Build a local web platform that discovers devices from a GNS3 lab on the same machine, shows them in an inventory, and lets an authenticated user run commands over GNS3 console (Telnet) or SSH.

The first lab to support is a small topology: two routers, one switch, one PC.

Phase 2 adds: VLAN creation, IP change, config save, and running-config backup.
Out of original phase-1 scope: manual device add, multi-vendor beyond Cisco IOS and Juniper Junos.

## 2. Users and success

Primary user: a network lab operator running GNS3 locally.

Success when:

- User logs in and sees a dashboard of discovered GNS3 nodes.
- User clicks Discover and the platform lists the current GNS3 project nodes (routers, switch, PC).
- User opens a device and runs a show command via console without needing a management IP.
- User runs a command via SSH when management IP and credentials are available.
- If GNS3 is down, the UI shows a clear connection error instead of an empty inventory with no explanation.

## 3. Architecture

```mermaid
graph LR
    UI["React Vite UI"] -->|"/api"| API["FastAPI"]
    API --> Auth["JWT Auth"]
    API --> PG["PostgreSQL"]
    API --> GNS3["GNS3 REST 127.0.0.1:3080"]
    API --> Cons["Telnet Console"]
    API --> SSH["Netmiko SSH"]
    Cons --> Nodes["GNS3 nodes"]
    SSH --> Nodes
```

- Frontend: React + Vite. Reverse-proxy `/api` to FastAPI so preview exposes one port.
- Backend: FastAPI. Owns auth, GNS3 client, session execution, audit logs.
- Database: PostgreSQL.
- Device access: Netmiko for SSH (`cisco_ios`, `juniper`). Python Telnet for GNS3 console ports.
- GNS3: local controller at `http://127.0.0.1:3080` by default. No separate remote GNS3 server required.

## 4. Device source rule

Inventory is GNS3-only.

- Devices enter the database only through Discover.
- There is no add-device form.
- Discover upserts nodes from the open/selected GNS3 project.
- Nodes missing from GNS3 after Discover are marked `absent` (kept in history, hidden from the default inventory list).
- Credentials and optional management IP are edited on an already-discovered device; they are not a second inventory source.

## 5. Data model

### users

- `id` UUID PK
- `username` unique
- `password_hash`
- `role` `admin` | `operator`
- `created_at`

Bootstrap: one admin user created on first start from environment variables `NAP_ADMIN_USER` and `NAP_ADMIN_PASSWORD` (defaults `admin` / `admin` for local lab only).

### gns3_settings

Single row of local connection settings.

- `id` integer PK, always 1
- `protocol` `http` | `https` default `http`
- `host` default `127.0.0.1`
- `port` default `3080`
- `username` nullable
- `password` nullable (encrypted at rest)
- `project_id` nullable — last selected project
- `updated_at`

### devices

- `id` UUID PK
- `gns3_node_id` unique
- `gns3_project_id`
- `name`
- `node_type` raw GNS3 node type string
- `vendor` `cisco` | `juniper` | `unknown`
- `role` `router` | `switch` | `pc` | `other`
- `status` `unknown` | `up` | `down` | `absent`
- `console_host` nullable
- `console_port` nullable
- `mgmt_ip` nullable
- `ssh_port` default 22
- `ssh_username` nullable
- `ssh_password` nullable (encrypted at rest)
- `last_seen_at`
- `created_at`
- `updated_at`

Vendor/role mapping:

- Name or GNS3 template containing `ios`, `csr`, `ioSv` -> Cisco router (or switch if template is a switch).
- Name or template containing `junos`, `vmx`, `vsrx` -> Juniper.
- VPCS / `vpcs` / `cloud` / `pc` -> PC, vendor unknown, SSH disabled unless mgmt IP is set.

### command_logs

- `id` UUID PK
- `device_id` FK devices
- `user_id` FK users
- `channel` `console` | `ssh`
- `command`
- `output`
- `status` `ok` | `error` | `blocked`
- `error_message` nullable
- `created_at`

## 6. GNS3 discovery

On `POST /api/gns3/discover`:

1. Read `gns3_settings`. If host unreachable, return `503` with message that GNS3 is not reachable at `host:port`.
2. `GET /v2/projects`. If `project_id` is set and still exists, use it. Otherwise use the first opened project; if none opened, return `409` asking the user to open a project in GNS3.
3. `GET /v2/projects/{id}/nodes`.
4. For each node, upsert `devices` by `gns3_node_id`.
5. Copy console host/port from the node (`console_host` or GNS3 host, `console` port).
6. Set `last_seen_at` now. Set `status` to `up` if node status is started, `down` if stopped.
7. Mark previously imported nodes in that project that were not returned as `absent`.

Discover does not start or stop nodes.

## 7. Command execution

`POST /api/devices/{id}/exec`

Body: `{ "command": "show ip interface brief", "channel": "console" | "ssh" }`

Rules:

- Reject if device `status` is `absent`.
- `channel=console`: Telnet to `console_host:console_port`. Send command, read until device prompt, return text. Timeout 30 seconds.
- `channel=ssh`: Netmiko connect with `mgmt_ip`, `ssh_port`, credentials. Device type from vendor. Timeout 30 seconds.
- Missing console port -> `400` console not available.
- Missing SSH IP or credentials -> `400` SSH not configured.
- Output and status stored in `command_logs`.

Dangerous commands require an extra field `confirm: true`. Without it, response is `409` with `status=blocked`.

Blocked exact commands (case-insensitive, trimmed):

- `reload`
- `reboot`
- `erase startup-config`
- `write erase`
- `request system reboot`
- `request system zeroize`

A confirmation prompt in the UI must be shown for these before retrying with `confirm: true`.

No interactive config sessions in this phase (`configure terminal` is allowed as a typed command but there is no config wizard).

## 8. API

All routes except login require `Authorization: Bearer <jwt>`.

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/api/auth/login` | username/password -> JWT |
| GET | `/api/auth/me` | current user |
| GET | `/api/gns3/settings` | current GNS3 settings |
| PUT | `/api/gns3/settings` | update host/port/auth/project |
| GET | `/api/gns3/projects` | list projects from live GNS3 |
| POST | `/api/gns3/discover` | import/refresh nodes |
| GET | `/api/devices` | inventory, default excludes `absent` |
| GET | `/api/devices/{id}` | device detail |
| PATCH | `/api/devices/{id}` | set mgmt_ip, ssh credentials, vendor override |
| POST | `/api/devices/{id}/connect-test` | probe console and/or SSH |
| POST | `/api/devices/{id}/exec` | run one command |
| GET | `/api/logs` | command history, filter by device |
| GET | `/api/dashboard` | counts: total, up, down, absent, last 10 logs |

JWT lifetime: 12 hours. Algorithm: HS256. Secret from `NAP_JWT_SECRET`.

Passwords at rest: Fernet key from `NAP_ENCRYPTION_KEY`.

## 9. UI pages

- `/login` — username, password.
- `/` dashboard — device counts, GNS3 reachability, recent logs, Discover button.
- `/devices` inventory table: name, role, vendor, status, console port, mgmt IP, actions (terminal, edit SSH).
- `/devices/:id` detail + credentials form + last logs.
- `/devices/:id/terminal` command box, channel toggle (console/SSH), output panel.
- `/settings` GNS3 host/port/user/pass and project selector.

UI language: Arabic labels, LTR technical fields (IPs, commands, output).

Dev server `allowedHosts` includes `.monkeycode-ai.live`. Vite proxies `/api` to FastAPI.

## 10. Error handling

- GNS3 down: dashboard banner + Discover returns 503 with the target URL.
- GNS3 up, no open project: 409 with instruction to open the lab project.
- Console/SSH failure: log row `error`, UI shows the exception text (auth failed, timeout, connection refused).
- Dangerous command without confirm: 409, no device access attempted.

## 11. Testing

Backend pytest:

- Login success/failure.
- Discover upsert + marking absent nodes.
- Exec console/SSH mocked (no real GNS3 in CI).
- Dangerous command blocked without `confirm`.
- Unauthenticated API returns 401.

Frontend: smoke render of login and inventory with mocked API.

## 12. Local run

- PostgreSQL, FastAPI on port 8000, Vite on port 5173 proxying `/api`.
- GNS3 GUI/local controller must be running for live discovery.
- Environment: `DATABASE_URL`, `NAP_JWT_SECRET`, `NAP_ENCRYPTION_KEY`, `NAP_ADMIN_USER`, `NAP_ADMIN_PASSWORD`.

## 13. Explicit non-goals (later phases)

- Manual inventory
- VLAN / IP change wizards
- Save configuration / backup
- Multi-user RBAC beyond admin vs operator
- Starting/stopping GNS3 nodes from the platform
- Vendors other than Cisco IOS and Juniper Junos
