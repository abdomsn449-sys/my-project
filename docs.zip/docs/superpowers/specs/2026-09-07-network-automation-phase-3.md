# Network Automation Platform — Phase 3: Lab Control

Date: 2026-09-07
Status: Implementation
Depends on: Phase 1 (discover + exec) and Phase 2 (IP / VLAN / save / backup)

## 1. Goal

Give the lab operator control over the GNS3 project from the web UI: start and stop nodes, see the live topology, run one command across many devices, add a static route, and let an admin manage users.

## 2. Success

- Admin or operator starts or stops a discovered node without opening the GNS3 GUI.
- Topology page draws nodes and links from the current GNS3 project.
- Playbook runs `show version` (or any command) on selected devices and stores per-device results.
- Static route wizard generates Cisco or Juniper commands and executes them.
- Admin creates an operator user. Operator cannot open user management.
- Interface snapshot shows parsed `show ip interface brief` / `show interfaces terse` output.

## 3. Out of scope

- Manual inventory add
- Vendors other than Cisco IOS and Juniper Junos
- Starting the GNS3 application itself
- Config restore from backup (apply backup to device)

## 4. Data model

### playbook_runs

- `id` UUID PK
- `name` string
- `command` text
- `channel` `console` | `ssh`
- `user_id` FK users
- `status` `ok` | `error` | `partial` | `blocked`
- `created_at`

### playbook_results

- `id` UUID PK
- `playbook_run_id` FK playbook_runs
- `device_id` FK devices
- `status` `ok` | `error` | `blocked`
- `output` text
- `error_message` nullable
- `created_at`

No schema change to `users`, `devices`, or `command_logs`. Playbook runs also write `command_logs` rows for the existing audit trail.

## 5. API

All routes except login require JWT.

| Method | Path | Who | Purpose |
| --- | --- | --- | --- |
| POST | `/api/devices/{id}/start` | any user | GNS3 node start |
| POST | `/api/devices/{id}/stop` | any user | GNS3 node stop |
| POST | `/api/devices/{id}/reload-node` | any user | GNS3 node reload |
| GET | `/api/gns3/topology` | any user | nodes + links of selected project |
| GET | `/api/devices/{id}/interfaces` | any user | snapshot of interfaces |
| POST | `/api/devices/{id}/static-route` | any user | add static route |
| POST | `/api/playbooks/run` | any user | run one command on many devices |
| GET | `/api/playbooks` | any user | recent playbook runs |
| GET | `/api/playbooks/{id}` | any user | run + per-device results |
| GET | `/api/users` | admin | list users |
| POST | `/api/users` | admin | create user |
| PATCH | `/api/users/{id}` | admin | change role or password |

Dangerous playbook commands use the same confirm rule as single exec.

Static route body: `{ "network": "10.0.0.0", "mask": "24", "next_hop": "192.168.1.1", "channel": "console" }`.

Playbook body: `{ "name": "show-version", "command": "show version", "channel": "console", "device_ids": ["..."], "confirm": false }`. Empty `device_ids` means all non-absent devices.

## 6. UI

Arabic labels, LTR for IPs, commands, topology names.

- `/topology` SVG of GNS3 nodes/links, click node for device detail, start/stop on selected node.
- `/playbooks` device checkboxes, command box, history.
- `/logs` last 100 command logs with device filter.
- `/users` admin only.
- Devices table: start / stop / reload.
- Configure: static route form next to IP and VLAN.

## 7. RBAC

- `admin`: all routes including user management.
- `operator`: everything except `/api/users*`.
- An admin cannot change their own role away from admin.

## 8. Testing

- Static route command generation for Cisco and Juniper.
- Playbook with mocked console, two devices.
- Dangerous playbook blocked without confirm.
- Node start calls GNS3 POST (mocked).
- Topology maps links.
- Operator login gets 403 on POST `/api/users`.
